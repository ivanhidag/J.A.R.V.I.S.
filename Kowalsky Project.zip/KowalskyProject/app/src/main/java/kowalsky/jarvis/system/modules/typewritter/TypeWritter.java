package kowalsky.jarvis.system.modules.typewritter;

import android.content.Context;
import android.os.Handler;
import android.util.AttributeSet;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatTextView;

/**
 * Custom TextView that simulates typewriter animation effect.
 */
public class TypeWritter extends AppCompatTextView {

    private CharSequence text;
    private int index;
    private long delay = 75;
    private Handler handler = new Handler();

    /**
     * Constructor for creating a TypeWritter object.
     *
     * @param context the context of the application
     */
    public TypeWritter(Context context) {
        super(context);
    }

    /**
     * Constructor for creating a TypeWritter object with attributes.
     *
     * @param context the context of the application
     * @param attrs the attribute set
     */
    public TypeWritter(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    private Runnable characterAdder = new Runnable() {
        @Override
        public void run() {
            setText(text.subSequence(0, index++));
            if (index <= text.length()) {
                handler.postDelayed(characterAdder, delay);
            }
        }
    };

    /**
     * Animates the text by revealing it gradually in a typewriter effect.
     *
     * @param text the text to be animated
     */
    public void animateText(CharSequence text) {
        // Capitalize the first character of the text
        if (text != null && text.length() > 0) {
            char firstChar = Character.toUpperCase(text.charAt(0));
            this.text = firstChar + text.subSequence(1, text.length()).toString();
        } else {
            this.text = text;
        }

        this.index = 0;
        setText("");
        handler.removeCallbacks(characterAdder);
        handler.postDelayed(characterAdder, delay);
    }

    /**
     * Sets the delay between each character animation.
     *
     * @param delay the delay between characters in milliseconds
     */
    public void setCharacterDelay(long delay) {
        this.delay = delay;
    }

    /**
     * Builds a TypeWritter object with default settings.
     *
     * @param context the context of the application
     * @return a TypeWritter object
     */
    public static TypeWritter build(Context context) {
        TypeWritter typeWritter = new TypeWritter(context);
        typeWritter.setCharacterDelay(60);
        typeWritter.setTextSize(15);
        typeWritter.setMaxWidth(800);
        return typeWritter;
    }

    /**
     * Adapts the typing speed based on the length of the input text.
     *
     * @param typeWritter the TypeWritter object to adjust
     * @param input the input text
     */
    public static void adaptText(TypeWritter typeWritter, String input) {
        if (input.length() > 50) {
            typeWritter.setCharacterDelay(50);
        }
        if (input.length() > 150) {
            typeWritter.setCharacterDelay(40);
        }
        if (input.length() > 300) {
            typeWritter.setCharacterDelay(20);
        }
        if (input.length() > 600) {
            typeWritter.setCharacterDelay(10);
        }
    }
}
