package kowalsky.jarvis.system.jarvis.libs.speechanalyzer;

import java.util.ArrayList;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * The AnalyzerRegex class provides constants for speech analysis using regular expressions.
 */
public class AnalyzerRegex {

    /**
     * List of possible variations of the name "Jarvis" that may be detected in speech.
     */
    public static final ArrayList<String> JARVIS_NAMES = Stream.of(
            "jarvis", "yarvis", "llarvis", "jarbis", "yarbis", "llarbis", "jarvissa", "yas bis",
            "charles", "derbis", "darwins", "barbies", "jordi", "luis", "ya véis", "jarviss",
            "jerrys"
    ).collect(Collectors.toCollection(ArrayList::new));

    /**
     * List of regular expressions to normalize accents in speech.
     */
    public static final ArrayList<String[]> REGEX_ACCENTS = Stream.of(
            new String[]{"á", "a"}, new String[]{"ó", "o"}, new String[]{"ú", "u"},
            new String[]{"é", "e"}, new String[]{"í", "i"}, new String[]{"ü", "u"}
    ).collect(Collectors.toCollection(ArrayList::new));

    /**
     * List of common articles and conjunctions in speech.
     */
    public static final ArrayList<String> REGEX_ARTICLES = Stream.of(
            "a", "al", "las", "ante", "bajo", "cabe", "con", "contra", "de", "del", "desde",
            "durante", "en", "entre", "hacia", "hasta", "mediante", "para", "por", "no",
            "segun", "sin", "so", "sobre", "tras", "durante", "mas", "pero", "aunque",
            "sin embargo", "no obstante", "sino", "luego", "porque", "pues", "ya que",
            "asi que", "entonces", "mientras", "como si", "cuando", "a pesar de que",
            "si", "como", "ademas", "incluso", "tambien", "siquiera", "el", "lo", "lu", "li", "la",
            "u", "o", "e", "i"
    ).collect(Collectors.toCollection(ArrayList::new));
}
