package kowalsky.jarvis.system;

import android.content.Context;
import android.os.Bundle;
import android.view.Menu;
import kowalsky.jarvis.system.UI.HomeFragment;
import kowalsky.jarvis.system.bbdd.Database;
import kowalsky.jarvis.system.jarvis.core.CoreTask;
import kowalsky.jarvis.system.jarvis.core.speechrecognizer.SpeechRecognizerModel;
import kowalsky.jarvis.system.modules.package_opening.PackageOpener;
import kowalsky.jarvis.system.modules.system_modules.PermissionHelper;
import kowalsky.jarvis.system.jarvis.libs.Values;
import kowalsky.jarvis.system.modules.decission_taking.ActionMapper;
import kowalsky.jarvis.system.modules.action_management.ResponseHelper;
import kowalsky.jarvis.system.modules.text_processing.SpeechAnalyzer;
import com.google.android.material.navigation.NavigationView;
import androidx.lifecycle.MutableLiveData;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.AppCompatActivity;
import kowalsky.jarvis.system.jarvis.core.CoreResponseListener;
import kowalskyproject.jarvis.system.R;
import kowalskyproject.jarvis.system.databinding.ActivityMainBinding;

/**
 * This class represents the main activity of the application.
 * It controls the navigation between fragments and manages user interactions.
 */
public class MainActivity extends AppCompatActivity implements CoreResponseListener{

    private AppBarConfiguration mAppBarConfiguration;
    private ActivityMainBinding binding;
    private NavController navController;

    // Values Network Management
    public static final MutableLiveData<String> SystemPost = new MutableLiveData<>();
    public static final MutableLiveData<String> UserPost = new MutableLiveData<>();
    public static final MutableLiveData<String> Query = new MutableLiveData<>();

    // MainActivity
    private Boolean IA = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.appBarMain.toolbar);
        DrawerLayout drawer = binding.drawerLayout;
        NavigationView navigationView = binding.navView;
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.homeFragment, R.id.settingsFragment)
                .setOpenableLayout(drawer)
                .build();
        navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        NavigationUI.setupActionBarWithNavController(this, navController, mAppBarConfiguration);
        NavigationUI.setupWithNavController(navigationView, navController);

        // Boot up requirements and checks
        requestPermissions();
        checkSuperAdministrator(MainActivity.this);
        initAppSettings();

        // Update IA status
        HomeFragment.IA.observe(this, ia-> {this.IA = ia;});

        // IA handling the input
        MainActivity.Query.observe(this, this::intelliTextHandler);

        SpeechRecognizerModel.transcription.observe(this, speech-> {
            // Check if speech contains a key name
            if(SpeechAnalyzer.containsKey(speech.toLowerCase())){
                // Get speech content and set first capital letter
                speech = SpeechAnalyzer.getSpeechContent(speech);
                if(!speech.trim().isEmpty()){
                    // Trims if exists first space
                    if(speech.charAt(0) == ' '){
                        speech = speech.substring(1);
                    }
                    // Capitalize 1st character
                    speech = ("" + speech.charAt(0)).toUpperCase() + speech.substring(1);
                    // Post user speech content
                    UserPost.setValue(speech);
                    // IA handling the input
                    intelliTextHandler(speech);
                }
            }
        });
    }

    @Override
    public void onResponseReceived(String result) {
        // Result carries the content of the IA response
        ResponseHelper.manageResponse(MainActivity.this, result.toLowerCase());
        SystemPost.setValue(result);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    private void requestPermissions(){
        PermissionHelper permissionHelper = new PermissionHelper(MainActivity.this);

        // Request permissions continuously until all are granted
        permissionHelper.requestPermissions();
    }

    private void checkSuperAdministrator(Context context){
        Database database = new Database(context);
        if(database.getUserThroughUsername(Values.SUPER_ADMINISTRATOR_USERNAME) == null){
            database.addSuperAdminnistrator();
        }
    }

    private void intelliTextHandler(String input_text){
        // Normalize text speech content
        String normalizedText = SpeechAnalyzer.normalizarTexto(input_text);
        if(this.IA){
            String action = ActionMapper.mapTextToAction(SpeechAnalyzer.normalizarTexto(input_text.toLowerCase()));
            if(action.equals("open_package")){
                PackageOpener.runPackage(MainActivity.this,normalizedText);
            }
            if(action.equals("unknown_action")){
                CoreTask.execute(input_text,MainActivity.this);
            }
            else {
                CoreTask.setLastQuery(input_text);
                SystemPost.setValue(action.toLowerCase());
                ResponseHelper.manageResponse(MainActivity.this, action.toLowerCase());
            }
        }
    }

    private void initAppSettings(){
        // Clean last query activity
        CoreTask.setLastQuery("");
    }
}

/**
 *        ### Javadoc Explanation
 *
 *        - **Class-level comments** provide an overview of the class's purpose and its static map initialization.
 *        - **Method-level comments** explain the purpose, parameters, and return values of each method.
 *        - **Parameter tags (`@param`)** describe each method parameter.
 *        - **Return tags (`@return`)** describe what the method returns.
 */
