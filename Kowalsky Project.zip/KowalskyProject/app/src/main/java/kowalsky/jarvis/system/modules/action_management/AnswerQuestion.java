package kowalsky.jarvis.system.modules.action_management;

import android.util.Log;

import kowalsky.jarvis.system.MainActivity;
import kowalsky.jarvis.system.jarvis.core.CoreResponseListener;
import kowalsky.jarvis.system.jarvis.core.CoreTask;

/**
 * The AnswerQuestion class handles answering questions and receiving responses.
 */
public class AnswerQuestion implements CoreResponseListener {

    /**
     * Constructs an AnswerQuestion object.
     */
    public AnswerQuestion() {
    }

    /**
     * Responds to a question with a limited word count.
     * @param lastquery The last query received.
     */
    public void respond(String lastquery) {
        try {
            CoreTask.rawQuery(
                    "Respond to the following text " +
                            "(maximum 55 words). " +
                            "Text: " + lastquery,
                    AnswerQuestion.this);
        } catch (NullPointerException exception) {
            Log.e("ResponderAction", "ResponderAction: query null or empty");
        }
    }

    /**
     * Responds to a question without word count limitation.
     * @param lastquery The last query received.
     */
    public void large_response(String lastquery) {
        try {
            CoreTask.rawQuery(lastquery, AnswerQuestion.this);
        } catch (NullPointerException exception) {
            Log.e("ResponderAction", "ResponderAction: query null or empty");
        }
    }

    /**
     * Handles the response received from the CoreTask.
     * @param result The response received.
     */
    @Override
    public void onResponseReceived(String result) {
        try {
            MainActivity.SystemPost.setValue(result);
        } catch (NullPointerException exception) {
            Log.e("ResponderAction", "ResponderAction: result null or empty");
        }
    }
}
