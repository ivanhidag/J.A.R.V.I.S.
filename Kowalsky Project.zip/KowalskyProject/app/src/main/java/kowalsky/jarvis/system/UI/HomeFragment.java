package kowalsky.jarvis.system.UI;
/**
 * This class represents the Home Fragment of the UI.
 * It provides functionality for managing user interactions within the home screen.
 */
import static android.content.Context.MODE_PRIVATE;

import android.annotation.SuppressLint;
import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.MutableLiveData;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;

import java.util.Objects;

import kowalsky.jarvis.system.MainActivity;
import kowalsky.jarvis.system.bbdd.Database;
import kowalsky.jarvis.system.jarvis.core.CoreResponseListener;
import kowalsky.jarvis.system.jarvis.core.service.BackgroundService;
import kowalsky.jarvis.system.jarvis.libs.Values;
import kowalsky.jarvis.system.modules.system_modules.AudioHelper;
import kowalsky.jarvis.system.modules.system_modules.AutoScroller;
import kowalsky.jarvis.system.modules.system_modules.KeyboardVisibilityListener;
import kowalsky.jarvis.system.modules.typewritter.TypeWritter;
import kowalskyproject.jarvis.system.R;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link HomeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class HomeFragment extends Fragment implements CoreResponseListener{

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    private ScrollView home_scrollview; private LinearLayout home_scroll_layout; EditText input_edittext;
    private ImageButton app_volume_btn;

    public static final MutableLiveData<Boolean> IA = new MutableLiveData<>();

    /**
     * Default constructor for HomeFragment.
     */
    public HomeFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment HomeFragment.
     */
    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Navigation
        NavController navController = Navigation.findNavController(view);
        // Check if session initiated
        try {
            try (Database database = new Database(requireActivity())) {
                if (!database.isLogged()) {
                    navController.navigate(R.id.authenticationFragment);
                }
            }
        } catch (Exception e){
            Log.e("HomeFragment","Err: "+e);
        }
        // Update IA and Service status
        checkIAstatus(view);
        checkServiceStatus(view);

        // Components
        home_scrollview = view.findViewById(R.id.home_scrollview);
        home_scroll_layout = view.findViewById(R.id.home_scroll_layout);
        app_volume_btn = view.findViewById(R.id.app_volume_btn);
        input_edittext = view.findViewById(R.id.input_edittext);
        LinearLayout footer_layout = view.findViewById(R.id.footer_layout);
        ImageButton input_controls_btn = view.findViewById(R.id.input_controls_btn);
        @SuppressLint("UseSwitchCompatOrMaterialCode")
        Switch service_switch = view.findViewById(R.id.service_switch);
        @SuppressLint("UseSwitchCompatOrMaterialCode")
        Switch ia_switch = view.findViewById(R.id.ia_switch);

        // App Volume Btn
        app_volume_btn.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("UseCompatLoadingForDrawables")
            @Override
            public void onClick(View v) {
                AudioHelper audioHelper = new AudioHelper(requireActivity());
                SharedPreferences prefs = requireActivity().getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
                boolean isMuted = prefs.getBoolean("isMuted", false);
                if(!isMuted){
                    // Change image
                    app_volume_btn.setBackground(ContextCompat.getDrawable(requireActivity(), R.drawable.ic_volume_off_foreground));
                    // Mute app
                    audioHelper.muteApp();
                }
                else {
                    // Change image
                    app_volume_btn.setBackground(ContextCompat.getDrawable(requireActivity(), R.drawable.ic_volume_on_foreground));
                    // Mute app
                    audioHelper.unmuteApp();
                }
            }
        });

        service_switch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(service_switch.isChecked()){
                    requireActivity().startService(new Intent(requireActivity(),BackgroundService.class));
                }
                else requireActivity().stopService(new Intent(requireActivity(),BackgroundService.class));
            }
        });

        // Setting invisible footer_layout;
        input_controls_btn.setVisibility(View.GONE);
        input_controls_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                v.setVisibility(View.GONE);
                footer_layout.setVisibility(View.VISIBLE);
            }
        });

        // IA switch management
        ia_switch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ia_switch.isChecked()){
                    Thread thread = new Thread(){
                        public void run(){
                            new Handler(Looper.getMainLooper()).post(()->IA.setValue(true));
                        }
                    };thread.start();
                    // Guardar el estado del volúmen en SharedPreferences
                    requireActivity().getSharedPreferences("app_prefs", MODE_PRIVATE).edit().putBoolean("ia", true).apply();
                }else {
                    Thread thread = new Thread(){
                        public void run(){
                            new Handler(Looper.getMainLooper()).post(()->IA.setValue(false));
                        }
                    };thread.start();
                    // Guardar el estado del volúmen en SharedPreferences
                    requireActivity().getSharedPreferences("app_prefs", MODE_PRIVATE).edit().putBoolean("ia", false).apply();
                }
            }
        });

        // Text box input management
        ImageButton send_input_imagebutton = view.findViewById(R.id.send_input_imagebutton);
        send_input_imagebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String input = input_edittext.getText().toString();
                // Check for empty string
                if(!input.isEmpty() && !input.trim().isEmpty()){
                    if(Boolean.TRUE.equals(IA.getValue())){
                        displayUserOutput(input);
                        input_edittext.setText("");
                        MainActivity.Query.setValue(input);
                    }
                    else {
                        displayUserOutput("The AI is not active");
                    }
                    home_scroll_layout.setPadding(40, 35, 40, 20);
                }
            }
        });

        // Listen in case of display needed from another CoreResponseListener
        MainActivity.SystemPost.observe(getViewLifecycleOwner(), response-> {
            home_scroll_layout.setPadding(40, 35, 40, 20);
            displaySystemOutput(response);
        });
        // Listen in case of display needed from another CoreResponseListener
        MainActivity.UserPost.observe(getViewLifecycleOwner(), response-> {
            home_scroll_layout.setPadding(40, 35, 40, 20);
            displayUserOutput(response);
        });
        // Listen in case on change from volume level
        AudioHelper.VolumeLevel.observe(getViewLifecycleOwner(), level -> {
            if(level > 0){app_volume_btn.setBackground(ContextCompat.getDrawable(requireActivity(), R.drawable.ic_volume_on_foreground));}
            else app_volume_btn.setBackground(ContextCompat.getDrawable(requireActivity(), R.drawable.ic_volume_off_foreground));
        });

        // Relocating input layout when keyboard event
        setKeyboardListener();
    }

    /**
     * Receive the response message from the IA.
     *
     * @param result The input message to be displayed.
     */
    @Override
    public void onResponseReceived(String result) {
        if(!result.isEmpty()){
            displaySystemOutput(result);
        }
        else Log.e("CORE RESPONSE","Respuesta es null o vacia");
    }

    /**
     * Display user output message.
     *
     * @param input The input message to be displayed.
     */
    @SuppressLint({"RtlHardcoded", "UseCompatLoadingForDrawables"})
    private void displayUserOutput(String input) {
        if(!input.isEmpty()){
            // Build typewritter output
            TypeWritter typeWritter = TypeWritter.build(getActivity());
            TypeWritter.adaptText(typeWritter,input);
            typeWritter.setTextColor(getResources().getColor(R.color.white));
            typeWritter.setBackground(getResources().getDrawable(R.drawable.custom_system_output_message_layout));
            LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
            );
            layoutParams.gravity = Gravity.RIGHT; // Set gravity to left
            layoutParams.bottomMargin = 15;
            typeWritter.setLayoutParams(layoutParams);
            home_scroll_layout.addView(typeWritter);
            typeWritter.animateText(input);

            // Scroll bottom
            AutoScroller.scroll(home_scrollview);
        }
    }

    /**
     * Display system output message.
     *
     * @param result The system response message to be displayed.
     */
    @SuppressLint({"UseCompatLoadingForDrawables", "RtlHardcoded"})
    private void displaySystemOutput(String result) {
        // Build typewritter output
        TypeWritter typeWritter = TypeWritter.build(getActivity());
        TypeWritter.adaptText(typeWritter,result);
        typeWritter.setTextColor(getResources().getColor(R.color.white));
        typeWritter.setBackground(getResources().getDrawable(R.drawable.custom_system_output_message_layout));
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
        layoutParams.gravity = Gravity.LEFT; // Set gravity to left
        layoutParams.bottomMargin = 15;
        typeWritter.setLayoutParams(layoutParams);
        home_scroll_layout.addView(typeWritter);
        typeWritter.animateText(result);

        // Scroll end bottom
        AutoScroller.scroll(home_scrollview);
    }

    /**
     * Check IA status and update UI.
     *
     * @param view The view to update IA switch status.
     */
    private void checkIAstatus(View view) {
        SharedPreferences prefs = requireActivity().getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
        Boolean IA = prefs.getBoolean("ia", false);
        if(IA){((Switch)view.findViewById(R.id.ia_switch)).setChecked(true);}
        HomeFragment.IA.setValue(IA);
    }

    /**
     * Check Service status and update UI.
     *
     * @param view The view to update service switch status.
     */
    private void checkServiceStatus(View view) {
        if(isServiceRunning(requireActivity())) {
            ((Switch)view.findViewById(R.id.service_switch)).setChecked(true);
        }
    }

    /**
     * Check if background service is running.
     *
     * @param context The application context.
     * @return True if service is running, false otherwise.
     */
    private boolean isServiceRunning(Context context) {
        ActivityManager activityManager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if (activityManager != null) {
            for (ActivityManager.RunningServiceInfo service : activityManager.getRunningServices(Integer.MAX_VALUE)) {
                if (BackgroundService.class.getName().equals(service.service.getClassName())) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Set keyboard visibility listener.
     */
    private void setKeyboardListener(){
        KeyboardVisibilityListener.setKeyboardVisibilityListener(requireActivity(), new KeyboardVisibilityListener.OnKeyboardVisibilityListener() {
            @Override
            public void onVisibilityChanged(boolean visible) {
                if (visible) {
                    // Get the current LayoutParams of the ScrollView
                    LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) home_scrollview.getLayoutParams();
                    // Set the new height
                    layoutParams.height = home_scrollview.getHeight() - Values.KEYBOARD_HEIGHT_IN_PX+500;
                    // Apply the updated LayoutParams back to the ScrollView
                    home_scrollview.setLayoutParams(layoutParams);
                    input_edittext.requestFocus();
                } else {
                    // Get the current LayoutParams of the ScrollView
                    LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) home_scrollview.getLayoutParams();
                    // Set the new height
                    layoutParams.height = 1450;
                    // Apply the updated LayoutParams back to the ScrollView
                    home_scrollview.setLayoutParams(layoutParams);
                }
            }
        });
    }

}

/**
 *        ### Javadoc Explanation
 *
 *        - **Class-level comments** provide an overview of the class's purpose and its static map initialization.
 *        - **Method-level comments** explain the purpose, parameters, and return values of each method.
 *        - **Parameter tags (`@param`)** describe each method parameter.
 *        - **Return tags (`@return`)** describe what the method returns.
 */