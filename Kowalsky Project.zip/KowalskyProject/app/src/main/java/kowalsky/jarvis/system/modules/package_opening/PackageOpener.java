package kowalsky.jarvis.system.modules.package_opening;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.util.Log;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class PackageOpener {

    /**
     * Method to open another app by its package name.
     *
     * @param context     The context of the calling activity.
     * @param packageName The package name of the app to be opened.
     * @return True if the app was successfully opened, false otherwise.
     */
    private static boolean openApp(Context context, String packageName) {
        PackageManager packageManager = context.getPackageManager();
        Intent intent = packageManager.getLaunchIntentForPackage(packageName);
        if (intent != null) {
            intent.addCategory(Intent.CATEGORY_LAUNCHER);
            context.startActivity(intent);
            return true;
        } else {
            return false;
        }
    }

    /**
     * Obtiene todos los nombres de paquetes de aplicaciones.
     *
     * @return Un array de String con todos los nombres de paquetes de aplicaciones.
     */
    public static String[] getAllPackages() {
        return APPS_MAP.keySet().toArray(new String[0]);
    }

    /**
     * Obtiene todos los nombres de aplicaciones.
     *
     * @return Un array de String con todos los nombres de aplicaciones.
     */
    public static String[] getAllNames() {
        return APPS_MAP.values().stream().flatMap(Arrays::stream).toArray(String[]::new);
    }

    /**
     * Busca el nombre de una aplicación dentro de una cadena de texto.
     *
     * @param inputString La cadena de texto en la que buscar el nombre de la aplicación.
     * @return El nombre del paquete de la aplicación si se encuentra una coincidencia, null en caso contrario.
     */
    private static String searchAppName(String inputString) {
        String matchedPackage = null;
        int earliestIndex = Integer.MAX_VALUE;
        int longestLength = 0;

        for (Map.Entry<String, String[]> entry : APPS_MAP.entrySet()) {
            for (String associatedName : entry.getValue()) {
                int index = inputString.toLowerCase().indexOf(associatedName.toLowerCase());
                if (index != -1) {
                    boolean isBetterMatch = false;

                    // Check if it's an exact match
                    if (associatedName.equalsIgnoreCase(inputString.trim())) {
                        isBetterMatch = true;
                    } else if (index < earliestIndex) {
                        isBetterMatch = true;
                    } else if (index == earliestIndex && associatedName.length() > longestLength) {
                        isBetterMatch = true;
                    }

                    if (isBetterMatch) {
                        matchedPackage = entry.getKey();
                        earliestIndex = index;
                        longestLength = associatedName.length();
                    }
                }
            }
        }
        return matchedPackage;
    }

    /**
     * Ejecuta la aplicación correspondiente al texto de entrada.
     *
     * @param context     El contexto de la actividad que llama.
     * @param input_text  El texto de entrada que puede contener el nombre de una aplicación.
     * @return true si se ejecutó la aplicación correctamente, false en caso contrario.
     */
    public static boolean runPackage(Context context, String input_text) {
        String app_package = searchAppName(input_text);
        openApp(context, app_package);
        return false;
    }

    /**
     * Mapa que contiene los nombres de paquetes de aplicaciones mapeados a sus nombres asociados.
     */
    public static final Map<String, String[]> APPS_MAP = new HashMap<String, String[]>() {{
        put("com.spotify.music", new String[]{"spotify", "espoti"});
        put("com.android.settings", new String[]{"ajustes"});
        put("com.android.chrome", new String[]{"chrome", "google chrome"});
        put("com.imaginbank.app", new String[]{"imagine", "banco", "imagin bank"});
        put("com.instagram.android", new String[]{"instagram", "insta"});
        put("com.google.android.gm", new String[]{"email", "mail", "gmail", "correo"});
        put("com.google.android.apps.docs", new String[]{"drive", "google drive"});
        put("com.google.android.apps.maps", new String[]{"maps", "google maps"});
        put("com.shazam.android", new String[]{"shazam"});
        put("com.tranzmate", new String[]{"muvit", "moovit", "move it"});
        put("com.android.deskclock", new String[]{"reloj"});
        put("com.miui.calculator", new String[]{"calculadora"});
        put("com.miui.notes", new String[]{"notas"});
        put("com.netflix.mediaclient", new String[]{"netflix", "niflix"});
        put("com.supercell.clashroyale", new String[]{"royale", "clash royale"});
        put("com.whatsapp", new String[]{"whatsapp", "whats up", "whats app"});
        put("com.google.android.youtube", new String[]{"youtube"});
        put("com.supercell.brawlstars", new String[]{"brawl stars", "brawl"});
        put("com.supercell.clashofclans", new String[]{"clash of clans", "clash"});
    }};
}
