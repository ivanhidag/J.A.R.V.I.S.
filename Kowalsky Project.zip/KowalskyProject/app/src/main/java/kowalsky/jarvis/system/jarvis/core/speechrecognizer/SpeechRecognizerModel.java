package kowalsky.jarvis.system.jarvis.core.speechrecognizer;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import androidx.lifecycle.MutableLiveData;
import java.util.ArrayList;

/**
 * SpeechRecognizerModel handles speech recognition functionality using Android's SpeechRecognizer API.
 */
public class SpeechRecognizerModel {

    private static final String RECOGNITION_LANGUAGE_CODE = "es-ES";

    private SpeechRecognizer speechRecognizer;
    private Intent speechRecognizerIntent;

    private Context context;
    private Boolean prepared = false;

    public static final MutableLiveData<String> transcription = new MutableLiveData<>();

    /**
     * Constructor for SpeechRecognizerModel.
     *
     * @param context the application context.
     */
    public SpeechRecognizerModel(Context context){
        this.context = context;
    }

    /**
     * Creates and configures the SpeechRecognizer instance.
     */
    public void create(){
        speechRecognizer = android.speech.SpeechRecognizer.createSpeechRecognizer(context.getApplicationContext());
        speechRecognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, RECOGNITION_LANGUAGE_CODE);
        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        speechRecognizerIntent.putExtra(RecognizerIntent.EXTRA_PROMPT, "");
        speechRecognizer.setRecognitionListener(new RecognitionListener() {
            @Override
            public void onReadyForSpeech(Bundle params) {}
            @Override
            public void onBeginningOfSpeech() {}
            @Override
            public void onRmsChanged(float rmsdB) {}
            @Override
            public void onBufferReceived(byte[] buffer) {}
            @Override
            public void onEndOfSpeech() {}
            @Override
            public void onError(int error) {
                // Mute system sound
                AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
                audioManager.setStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_MUTE, 0);
                // Restarts recognition
                speechRecognizer.startListening(speechRecognizerIntent);
            }
            @Override
            public void onResults(Bundle results) {
                // Get recognition results
                ArrayList<String> data = results.getStringArrayList(android.speech.SpeechRecognizer.RESULTS_RECOGNITION);
                // Send results
                transcription.setValue(data.get(0));
                // Mute system sound
                AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
                audioManager.setStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_MUTE, 0);
                // Restarts recognition
                speechRecognizer.startListening(speechRecognizerIntent);
            }
            @Override
            public void onPartialResults(Bundle partialResults) {}
            @Override
            public void onEvent(int eventType, Bundle params) {}
        });

        this.prepared = true;
    }

    /**
     * Starts the speech recognition process.
     */
    public void start(){
        // Check preparations
        if(this.prepared){
            // Mute system sound
            AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
            audioManager.setStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_MUTE, 0);
            // Starts recognition
            speechRecognizer.startListening(speechRecognizerIntent);
        }
    }

    /**
     * Destroys the SpeechRecognizer instance and stops the recognition process.
     */
    public void destroy(){
        // Mute system sound
        AudioManager audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        audioManager.setStreamVolume(AudioManager.STREAM_NOTIFICATION, AudioManager.ADJUST_MUTE, 0);
        // Destroys speech recognizer
        this.speechRecognizer.stopListening();
        this.speechRecognizer.destroy();
    }
}
