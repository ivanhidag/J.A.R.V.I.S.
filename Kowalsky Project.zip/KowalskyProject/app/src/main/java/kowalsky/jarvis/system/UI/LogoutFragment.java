/**
 * This class represents a Logout Fragment in the UI.
 * It handles the logout process, including database operations and navigation.
 */
package kowalsky.jarvis.system.UI;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import kowalsky.jarvis.system.bbdd.Database;
import kowalsky.jarvis.system.modules.telephony_module.ContacHelper;
import kowalskyproject.jarvis.system.R;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link LogoutFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class LogoutFragment extends Fragment {

    // Parameters for fragment initialization
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // Parameters for fragment instance
    private String mParam1;
    private String mParam2;

    /**
     * Default constructor for LogoutFragment.
     */
    public LogoutFragment() {
        // Required empty public constructor
    }

    /**
     * Factory method to create a new instance of LogoutFragment.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment LogoutFragment.
     */
    public static LogoutFragment newInstance(String param1, String param2) {
        LogoutFragment fragment = new LogoutFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Initialize database and remove agenda
        Database database = new Database(requireActivity());
        ContacHelper.eliminateAgenda(requireActivity());
        // Perform logout operation
        database.logOut();
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_logout, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // Navigate to authentication fragment
        NavController navController = Navigation.findNavController(view);
        navController.navigate(R.id.authenticationFragment);
    }
}

/**
 *        ### Javadoc Explanation
 *
 *        - **Class-level comments** provide an overview of the class's purpose and its static map initialization.
 *        - **Method-level comments** explain the purpose, parameters, and return values of each method.
 *        - **Parameter tags (`@param`)** describe each method parameter.
 *        - **Return tags (`@return`)** describe what the method returns.
 */
