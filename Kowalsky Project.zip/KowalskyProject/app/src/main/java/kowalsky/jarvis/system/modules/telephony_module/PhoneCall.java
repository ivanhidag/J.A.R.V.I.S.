package kowalsky.jarvis.system.modules.telephony_module;

import android.content.Context;
import android.util.Log;

import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import kowalsky.jarvis.system.MainActivity;
import kowalsky.jarvis.system.jarvis.core.CoreResponseListener;
import kowalsky.jarvis.system.jarvis.core.CoreTask;
import kowalsky.jarvis.system.jarvis.entities.Contact;

/**
 * Class to handle phone call actions based on parsed contact names.
 */
public class PhoneCall implements CoreResponseListener {
    private Context context;

    /**
     * Constructor to initialize the context.
     *
     * @param context the application context
     */
    public PhoneCall(Context context){
        this.context = context;
    }

    /**
     * Method to get contact data based on the last query.
     *
     * @param lastquery the last query string
     */
    public void get_contact_data(String lastquery){
        try {
            CoreTask.rawQuery(
                    "Basándote en este texto: " + lastquery + ", ¿a quién llamarías según la siguiente agenda de contactos? La agenda de contactos es: " + ContacHelper.getAllContactNamesFormatted(context) + ". Responde solo con el nombre del contacto entre asteriscos (*contacto*), sin añadir otros caracteres o palabras. Si ninguno coincide, responde *ninguno*."
                    , PhoneCall.this);
        } catch (NullPointerException exception) {
            Log.e("ResponderAction", "ResponderAction: query null o vacia");
        }
    }

    /**
     * Matches the contact name from the response and makes a phone call if a match is found.
     *
     * @param response the response containing the contact name(s)
     */
    private void matchContactName(String response) {
        if(ContacHelper.getContact(this.context, response) != null){
            Contact matchedContact = ContacHelper.getContact(this.context, response);
            PhoneCallHelper phoneCallHelper = new PhoneCallHelper(this.context);
            phoneCallHelper.makePhoneCall(matchedContact.getContactnumber());
        } else if (!match_one_asterisk(response).isEmpty()) {
            ArrayList<String> values = match_one_asterisk(response);
            for (String value : values) {
                matchContact(value);
            }
        } else if (!match_double_asterisk(response).isEmpty()) {
            ArrayList<String> values = match_double_asterisk(response);
            for (String value : values) {
                matchContact(value);
            }
        } else if (!match_double_quotes(response).isEmpty()) {
            ArrayList<String> values = match_double_quotes(response);
            for (String value : values) {
                matchContact(value);
            }
        }
    }

    private void matchContact(String contactName){
        if (ContacHelper.getContact(this.context, contactName) != null) {
            Contact matchedContact = ContacHelper.getContact(this.context, contactName);
            PhoneCallHelper phoneCallHelper = new PhoneCallHelper(this.context);
            phoneCallHelper.makePhoneCall(matchedContact.getContactnumber());
        }
    }

    /**
     * Extracts values from a given text based on a predefined pattern.
     *
     * @param text the input text
     * @return a list of extracted values
     */
    public static ArrayList<String> match_one_asterisk(String text) {
        ArrayList<String> contacts = new ArrayList<>();

        // Regular expression to find *contact* pattern
        String patternString = "\\*([^*]+\\s+[^*]+)\\*";  // Updated pattern to handle composed names
        Pattern pattern = Pattern.compile(patternString);
        Matcher matcher = pattern.matcher(text);

        while (matcher.find()) {
            String contact = matcher.group(1);
            contact = contact.replaceAll("\\.*$", "");  // Remove trailing dots
            contacts.add(contact.trim());              // Trim any surrounding whitespace
        }

        return contacts;
    }

    /**
     * Extracts values from a given text based on a predefined pattern.
     * Specifically, it extracts values surrounded by double asterisks (**).
     *
     * @param text the input text
     * @return a list of extracted values
     */
    public static ArrayList<String> match_double_asterisk(String text) {
        ArrayList<String> contacts = new ArrayList<>();

        // Regular expression to find **contact** pattern
        String patternString = "\\*\\*([^*]+)\\*\\*";
        Pattern pattern = Pattern.compile(patternString);
        Matcher matcher = pattern.matcher(text);

        while (matcher.find()) {
            String contact = matcher.group(1);
            contact = contact.replaceAll("\\.*$", "");  // Remove trailing dots
            contacts.add(contact.trim());              // Trim any surrounding whitespace
        }

        return contacts;
    }

    /**
     * Extracts values from a given text based on a predefined pattern.
     * Specifically, it extracts values surrounded by double quotes (").
     *
     * @param text the input text
     * @return a list of extracted values
     */
    public static ArrayList<String> match_double_quotes(String text) {
        ArrayList<String> contacts = new ArrayList<>();

        // Regular expression to find "contact" pattern
        String patternString = "\"([^\"]+)\"";
        Pattern pattern = Pattern.compile(patternString);
        Matcher matcher = pattern.matcher(text);

        while (matcher.find()) {
            String contact = matcher.group(1);
            contact = contact.replaceAll("\\.*$", "");  // Remove trailing dots
            contacts.add(contact.trim());              // Trim any surrounding whitespace
        }

        return contacts;
    }

    /**
     * Callback method invoked when a response is received.
     *
     * @param result the result string received
     */
    @Override
    public void onResponseReceived(String result) {
        try {
            if (!result.contains("ninguno")) {
                matchContactName(result);
            } else {
                MainActivity.SystemPost.setValue("ninguno");
            }
            MainActivity.SystemPost.setValue(result);
        } catch (NullPointerException exception) {
            Log.e("ResponderAction", "ResponderAction: result null o vacio");
        }
    }
}
