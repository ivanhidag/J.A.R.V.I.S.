package kowalsky.jarvis.system.modules.telephony_module;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * Helper class to initiate phone calls.
 */
public class PhoneCallHelper {
    private Context context;
    private static final int REQUEST_CALL_PERMISSION = 1;

    /**
     * Constructor to initialize PhoneCallHelper with a given context.
     *
     * @param context The context to be used for initiating the phone call.
     */
    public PhoneCallHelper(Context context) {
        this.context = context;
    }

    /**
     * Initiates a phone call to the specified phone number.
     *
     * @param phoneNumber The phone number to call.
     */
    public void makePhoneCall(String phoneNumber) {
        if (phoneNumber == null || phoneNumber.isEmpty()) {
            Toast.makeText(context, "Phone number is invalid", Toast.LENGTH_SHORT).show();
            return;
        }

        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            requestCallPermission();
        } else {
            startCall(phoneNumber);
        }
    }

    /**
     * Starts the call activity if permission is granted.
     *
     * @param phoneNumber The phone number to call.
     */
    private void startCall(String phoneNumber) {
        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:" + phoneNumber));
        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
            context.startActivity(callIntent);
        } else {
            Toast.makeText(context, "Permission to make calls is required", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Requests the CALL_PHONE permission.
     */
    private void requestCallPermission() {
        if (context instanceof Activity) {
            ActivityCompat.requestPermissions((Activity) context, new String[]{Manifest.permission.CALL_PHONE}, REQUEST_CALL_PERMISSION);
        } else {
            Toast.makeText(context, "Cannot request permission, context is not an activity", Toast.LENGTH_SHORT).show();
        }
    }
}
