package kowalsky.jarvis.system.modules.system_modules;

import static android.content.Context.MODE_PRIVATE;

import android.content.Context;
import android.media.AudioManager;
import android.media.MediaPlayer;

import androidx.lifecycle.MutableLiveData;

/**
 * AudioHelper is a utility class for managing audio functions such as playing sounds, muting, unmuting,
 * and adjusting the volume of the app.
 */
public class AudioHelper {
    private AudioManager audioManager;
    private boolean isMuted;
    private Context context;
    private MediaPlayer mediaPlayer;

    public static final MutableLiveData<Integer> VolumeLevel = new MutableLiveData<>();

    /**
     * Constructor to initialize the AudioHelper with a given context.
     *
     * @param context The context to be used for accessing system services and resources.
     */
    public AudioHelper(Context context) {
        this.context = context.getApplicationContext();
        audioManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        isMuted = false;
    }

    /**
     * Plays a sound from a given resource ID.
     *
     * @param resourceId The resource ID of the sound to be played.
     */
    public void playSound(int resourceId) {
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
        mediaPlayer = MediaPlayer.create(context, resourceId);
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                mp.release();
            }
        });
        if (!isMuted) {
            mediaPlayer.start();
        }
    }

    /**
     * Mutes the app by setting the audio volume to 0 and saving the state in SharedPreferences.
     */
    public void muteApp() {
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0);
        isMuted = true;
        // Save the volume state in SharedPreferences
        context.getSharedPreferences("app_prefs", MODE_PRIVATE).edit().putBoolean("isMuted", true).apply();
        VolumeLevel.setValue(0);
    }

    /**
     * Unmutes the app by restoring the audio volume to 1/4 from the maximum and saving the state in SharedPreferences.
     */
    public void unmuteApp() {
        // Get the maximum volume for the music stream
        int maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);

        // Calculate one quarter of the maximum volume
        int quarterVolume = maxVolume / 4;

        // Set the stream volume to one quarter of the maximum volume
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, quarterVolume, 0);

        // Update the isMuted flag
        isMuted = false;

        // Save the updated mute state in SharedPreferences
        context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)
                .edit()
                .putBoolean("isMuted", false)
                .apply();
        VolumeLevel.setValue(25);
    }

    /**
     * Raises the volume of the app by one step.
     */
    public void raiseVolume() {
        if(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) == 0){VolumeLevel.setValue(1);}
        int currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        int maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        if (currentVolume < maxVolume) {
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, currentVolume + 1, AudioManager.FLAG_SHOW_UI);
        }
    }

    /**
     * Lowers the volume of the app by one step.
     */
    public void lowerVolume() {
        int currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
        if (currentVolume > 0) {
            audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, currentVolume - 1, AudioManager.FLAG_SHOW_UI);
        }
        if(audioManager.getStreamVolume(AudioManager.STREAM_MUSIC) == 0){VolumeLevel.setValue(0);}
    }

    /**
     * Releases the media player resources.
     */
    public void release() {
        if (mediaPlayer != null) {
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }
}
