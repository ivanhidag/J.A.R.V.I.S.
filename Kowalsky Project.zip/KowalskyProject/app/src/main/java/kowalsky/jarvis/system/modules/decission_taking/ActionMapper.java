package kowalsky.jarvis.system.modules.decission_taking;

import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import kowalsky.jarvis.system.jarvis.libs.Values;
import kowalsky.jarvis.system.modules.package_opening.PackageOpener;
import kowalsky.jarvis.system.modules.text_processing.SpeechAnalyzer;

/**
 * Class responsible for mapping text input to specific actions.
 */
public class ActionMapper {

    /**
     * Static map containing actions mapped to their respective text commands.
     */
    private static final Map<String, String> actions = new HashMap<>();

    /**
     * Maps the input text to a specific action.
     *
     * @param text The text to be mapped to an action.
     * @return The action corresponding to the input text, or "unknown_action" if no match is found.
     */
    public static String mapTextToAction(String text) {
        // Check if the text is a question
        if (isQuestion(text)) {
            return "answer_question";
        }
        if (isOpenPackage(text)) {
            return "open_package";
        }
        ArrayList<String[]> entries = new ArrayList<>();
        // Type of: ['index', 'entry.key']
        for (Map.Entry<String, String> entry : actions.entrySet()) {
            if (text.contains(entry.getKey())) {
                entries.add(new String[]{""+(text.indexOf(entry.getKey()) + entry.getKey().length()), entry.getValue()});
            }
        }
        String selected_entry = "unknown_action";
        int selected_index = Values.INT_MAX_VALUE;
        for (String[] entry : entries) {
            if (Integer.parseInt(entry[0]) < selected_index) {
                selected_index = Integer.parseInt(entry[0]);
                selected_entry = entry[1];
            }
        }
        return selected_entry;
    }

    /**
     * Gets an array of unique actions.
     *
     * @return An array of unique action values.
     */
    public static String[] getUniqueActions() {
        Set<String> uniqueActions = new HashSet<>(actions.values());
        return uniqueActions.toArray(new String[0]);
    }

    /**
     * Checks if the input text has the structure of a question.
     *
     * @param text The text to be checked.
     * @return true if the text is a question, false otherwise.
     */
    private static boolean isQuestion(String text) {
        // List of common words in Spanish questions
        String[] questionWords = {"que", "quien", "quienes", "donde", "cuando", "como", "cual", "cuales", "por que", "sabes", "puedes"};

        for (String word : questionWords) {
            if (text.contains(word)) {
                return true;
            }
        }

        // Additional checks for common question patterns
        String[] questionPatterns = {
                "sabes",
                "puedes",
                "me dices",
                "me puedes decir",
                "quiero saber"
        };

        for (String pattern : questionPatterns) {
            if (text.startsWith(pattern)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Checks if the input text indicates opening a package.
     *
     * @param text The text to be checked.
     * @return true if the text indicates opening a package, false otherwise.
     */
    private static boolean isOpenPackage(String text) {
        Boolean maybe = false;

        // List of app names that can be opened
        String[] apps_names = PackageOpener.getAllNames();

        for (String name : apps_names) {
            if (text.contains(name)) {
                maybe=true;
            }
        }

        if(maybe){
            // Additional checks for common app opening patterns
            String[] openAppPatterns = {
                    "abre el",
                    "abre la",
                    "ejecuta el",
                    "ejecuta la",
                    "inicia el",
                    "inicia la",
                    "abre",
                    "inicia",
            };

            for (String pattern : openAppPatterns) {
                if (text.startsWith(pattern)) {
                    return true;
                }
            }
        }

        return false;
    }

    /**
     * Gets a string with all unique action values.
     *
     * @return A string with all unique action values, separated by commas.
     */
    public static String getAllActionValues() {
        Set<String> uniqueValues = new HashSet<>(actions.values());
        StringBuilder result = new StringBuilder();
        for (String value : uniqueValues) {
            result.append(value).append(", ");
        }
        // Remove the last comma and space
        if (result.length() > 0) {
            result.setLength(result.length() - 2);
        }
        return result.toString();
    }

    static {
        // Initialization of the map with key-value pairs
        actions.put("silencio", "mute_system");
        actions.put("habla", "unmute_system");
        actions.put("puedes hablar", "unmute_system");
        actions.put("poner alarma", "set_alarm");
        actions.put("pon una alarma", "set_alarm");
        actions.put("avisame en", "set_alarm");
        actions.put("avisame a", "set_alarm");
        actions.put("llamar por movil", "phone_call");
        actions.put("llama por movil", "phone_call");
        actions.put("llama a", "phone_call");
        actions.put("suspender el movil", "suspend_phone");
        actions.put("suspende el movil", "suspend_phone");
        actions.put("cierra el pico", "mute_system");
        actions.put("buscar ruta", "search_route");
        actions.put("como voy", "search_route");
        actions.put("quiero ir", "search_route");
        actions.put("ir a", "search_route");
        actions.put("envia un correo", "send_email");
        actions.put("enviar un correo", "send_email");
        actions.put("escribe un correo", "send_email");
        actions.put("reproducir música", "play_music");
        actions.put("enviar mensaje", "send_message");
        actions.put("dile a", "send_message");
        actions.put("escribe a", "send_message");
        actions.put("sube el volumen", "set_volume");
        actions.put("baja el volumen", "set_volume");
        actions.put("sube un poco el volumen", "set_volume");
        actions.put("baja un poco el volumen", "set_volume");
        actions.put("esta muy alto", "set_volume");
        actions.put("esta muy bajo", "set_volume");
        actions.put("calla", "mute_system");
        actions.put("te puedes callar", "mute_system");
        actions.put("te quieres callar", "mute_system");
        actions.put("responder pregunta", "answer_question");
        actions.put("dime cuanto", "answer_question");
        actions.put("dime que", "answer_question");
        actions.put("dime como", "        answer_question");
        actions.put("dime cuando", "answer_question");
        actions.put("dime quien", "answer_question");
        actions.put("dime por que", "answer_question");
        actions.put("dime porque", "answer_question");
        actions.put("dime cuales", "answer_question");
        actions.put("dime cual", "answer_question");
        actions.put("dime donde", "answer_question");
        actions.put("mas informacion", "answer_question");
        actions.put("hola", "saludar");
    }
}

/**
 *        ### Javadoc Explanation
 *
 *        - **Class-level comments** provide an overview of the class's purpose and its static map initialization.
 *        - **Method-level comments** explain the purpose, parameters, and return values of each method.
 *        - **Parameter tags (`@param`)** describe each method parameter.
 *        - **Return tags (`@return`)** describe what the method returns.
 */

