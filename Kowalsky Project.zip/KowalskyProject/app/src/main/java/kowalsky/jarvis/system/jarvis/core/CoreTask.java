package kowalsky.jarvis.system.jarvis.core;

import kowalsky.jarvis.system.modules.decission_taking.ActionMapper;

/**
 * The CoreTask class is responsible for managing and executing queries to determine appropriate actions based on input text.
 */
public class CoreTask {

    private static String lastQueryContent;

    /**
     * Default constructor for CoreTask.
     */
    public CoreTask() {
    }

    /**
     * Retrieves the last query content.
     *
     * @return the content of the last query.
     */
    public static String getLastQuery() {
        return lastQueryContent;
    }

    /**
     * Sets the last query content.
     *
     * @param input the content to be set as the last query.
     */
    public static void setLastQuery(String input) {
        lastQueryContent = input;
    }

    /**
     * Executes a query to determine the most appropriate action based on the given transcript.
     *
     * @param transcript the input text to be analyzed.
     * @param listener the listener to handle the response.
     * @return the input transcript.
     */
    public static String execute(String transcript, CoreResponseListener listener) {
        String query =  "Based on this next input text (" + transcript + "), " +
                "choose the most appropriate action from the following list of possible actions: " +
                ActionMapper.getAllActionValues() + "." +
                " Important, if none of the actions are appropriate, choose unknown_action." +
                " And please answer only with the action like example_action";
        new Core(query, listener).execute();
        lastQueryContent = transcript;
        return transcript;
    }

    /**
     * Executes a raw query with the provided content.
     *
     * @param content the content to be sent as a query.
     * @param listener the listener to handle the response.
     */
    public static void rawQuery(String content, CoreResponseListener listener) {
        new Core(content, listener).execute();
        lastQueryContent = content;
    }
}
