package kowalsky.jarvis.system.jarvis.core;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * Core is an AsyncTask class for performing network operations to interact with an API.
 * It sends a query to a specified endpoint and retrieves the response.
 */
public class Core extends AsyncTask<Void, Void, String> {

    private static final String API_KEY = "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";
    private static final String MODEL_NAME = "llama3-8b-8192";

    private String query;
    private CoreResponseListener listener; // Interface instance to communicate back to listeners

    /**
     * Constructor for Core.
     *
     * @param query    the query to send to the API.
     * @param listener the listener to receive the API response.
     */
    public Core(String query, CoreResponseListener listener) {
        this.query = query;
        this.listener = listener; // Initialize the interface instance
    }

    /**
     * Performs network operations in a background thread.
     *
     * @param voids no parameters are required for this method.
     * @return the response content from the API.
     */
    @Override
    protected String doInBackground(Void... voids) {
        OkHttpClient client = new OkHttpClient();

        JSONObject jsonBody = new JSONObject();
        try {
            if (!this.query.trim().isEmpty() && !(this.query.trim() == null)) {
                // Constructing JSON body for the request
                JSONArray messagesArray = new JSONArray();
                JSONObject messageObject = new JSONObject();
                messageObject.put("role", "user");
                messageObject.put("content", query);
                messagesArray.put(messageObject);

                jsonBody.put("messages", messagesArray);
                jsonBody.put("model", MODEL_NAME);
            } else {
                Log.e("Error query", "Error: empty or null query");
            }
        } catch (JSONException | NullPointerException e) {
            Log.e("Core", "Core: json, null o vacia");
        }

        RequestBody requestBody = RequestBody.create(MediaType.get("application/json"), jsonBody.toString());
        Request request = new Request.Builder()
                .url("https://api.groq.com/openai/v1/chat/completions")
                .header("Authorization", "Bearer " + API_KEY)
                .header("Content-Type", "application/json")
                .post(requestBody)
                .build();

        try {
            Response response = client.newCall(request).execute();
            if (response.isSuccessful()) {
                // Parsing and extracting the response
                String responseBody = response.body().string();
                JSONObject responseJSON = new JSONObject(responseBody);
                JSONArray choicesARRAY = responseJSON.getJSONArray("choices");
                JSONObject choicesJSON = new JSONObject(choicesARRAY.getJSONObject(0).toString());
                JSONObject messageJSON = choicesJSON.getJSONObject("message");
                String content = messageJSON.getString("content");
                return content;
            } else {
                // Log an error if the response is not successful
                Log.e("Response Error", "Unsuccessful response: " + response.code());
                return null;
            }
        } catch (IOException | JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    /**
     * Runs on the main (UI) thread after doInBackground completes.
     *
     * @param answer the response content from the API.
     */
    @Override
    protected void onPostExecute(String answer) {
        super.onPostExecute(answer);
        // Call the interface method with the result
        listener.onResponseReceived(answer);
    }
}

/**
 *        ### Javadoc Explanation
 *
 *        - **Class-level comments** provide an overview of the class's purpose and its static map initialization.
 *        - **Method-level comments** explain the purpose, parameters, and return values of each method.
 *        - **Parameter tags (`@param`)** describe each method parameter.
 *        - **Return tags (`@return`)** describe what the method returns.
 */
