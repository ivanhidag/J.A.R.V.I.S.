package kowalsky.jarvis.system.jarvis.core;

/**
 * CoreResponseListener is an interface for the callback to handle the response received from the Core class.
 */
public interface CoreResponseListener {

    /**
     * Called when the API response is received.
     *
     * @param result the result returned from the API.
     */
    void onResponseReceived(String result);
}

/**
 *        ### Javadoc Explanation
 *
 *        - **Class-level comments** provide an overview of the class's purpose.
 *        - **Method-level comments** explain the purpose, parameters, and return values of each method.
 *        - **Parameter tags (`@param`) describe each method parameter.
 *        - **Return tags (`@return`) describe what the method returns.
 */
