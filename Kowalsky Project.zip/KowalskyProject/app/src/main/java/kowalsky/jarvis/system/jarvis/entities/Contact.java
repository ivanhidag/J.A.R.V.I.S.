package kowalsky.jarvis.system.jarvis.entities;

/**
 * The Contact class represents a contact entity with properties such as contact name and contact number.
 */
public class Contact {

    private String contactnumber;
    private String contactname;

    /**
     * Constructs a Contact object with the specified contact name and contact number.
     *
     * @param contactname the name of the contact.
     * @param contactnumber the phone number of the contact.
     */
    public Contact(String contactname, String contactnumber) {
        this.contactname = contactname;
        this.contactnumber = contactnumber;
    }

    /**
     * Gets the phone number of the contact.
     *
     * @return the phone number of the contact.
     */
    public String getContactnumber() {
        return contactnumber;
    }

    /**
     * Sets the phone number of the contact.
     *
     * @param contactnumber the phone number of the contact.
     */
    public void setContactnumber(String contactnumber) {
        this.contactnumber = contactnumber;
    }

    /**
     * Gets the name of the contact.
     *
     * @return the name of the contact.
     */
    public String getContactname() {
        return contactname;
    }

    /**
     * Sets the name of the contact.
     *
     * @param contactname the name of the contact.
     */
    public void setContactname(String contactname) {
        this.contactname = contactname;
    }
}
