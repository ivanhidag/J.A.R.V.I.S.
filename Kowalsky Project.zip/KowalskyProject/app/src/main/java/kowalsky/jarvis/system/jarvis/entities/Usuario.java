package kowalsky.jarvis.system.jarvis.entities;

/**
 * The Usuario class represents a user entity with properties such as username, password, email, and administrator status.
 */
public class Usuario {

    private String password;
    private String email;
    private String username;
    private String id;
    private Boolean administrator;

    /**
     * Constructs a Usuario object with the specified username, password, email, and administrator status.
     *
     * @param username the username of the user.
     * @param password the password of the user.
     * @param email the email of the user.
     * @param administrator the administrator status of the user.
     */
    public Usuario(String username, String password, String email, Boolean administrator) {
        this.username = username;
        this.email = email;
        this.password = password;
        this.administrator = administrator;
    }

    /**
     * Gets the administrator status of the user.
     *
     * @return the administrator status of the user.
     */
    public Boolean getAdministrator() {
        return administrator;
    }

    /**
     * Sets the administrator status of the user.
     *
     * @param administrator the administrator status of the user.
     */
    public void setAdministrator(Boolean administrator) {
        this.administrator = administrator;
    }

    /**
     * Gets the unique identifier of the user.
     *
     * @return the unique identifier of the user.
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the unique identifier of the user.
     *
     * @param id the unique identifier of the user.
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Gets the username of the user.
     *
     * @return the username of the user.
     */
    public String getUsername() {
        return username;
    }

    /**
     * Sets the username of the user.
     *
     * @param username the username of the user.
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Gets the password of the user.
     *
     * @return the password of the user.
     */
    public String getPassword() {
        return password;
    }

    /**
     * Sets the password of the user.
     *
     * @param password the password of the user.
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Gets the email of the user.
     *
     * @return the email of the user.
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the email of the user.
     *
     * @param email the email of the user.
     */
    public void setEmail(String email) {
        this.email = email;
    }
}
