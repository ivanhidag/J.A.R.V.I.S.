/**
 * This class represents a Register Fragment in the UI.
 * It handles user registration process, including input validation and database operations.
 */
package kowalsky.jarvis.system.UI;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import kowalsky.jarvis.system.bbdd.Database;
import kowalsky.jarvis.system.jarvis.entities.Usuario;
import kowalsky.jarvis.system.modules.validations.FieldValidator;
import kowalskyproject.jarvis.system.R;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link RegisterFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class RegisterFragment extends Fragment {

    // Parameters for fragment initialization
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";
    private static final String USER_TAG = "USEREXISTS";
    private static final String EMAIL_TAG = "EMAILEXISTS";

    // Parameters for fragment instance
    private String mParam1;
    private String mParam2;

    /**
     * Default constructor for RegisterFragment.
     */
    public RegisterFragment() {
        // Required empty public constructor
    }

    /**
     * Factory method to create a new instance of RegisterFragment.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment RegisterFragment.
     */
    public static RegisterFragment newInstance(String param1, String param2) {
        RegisterFragment fragment = new RegisterFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_register, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // Navigation
        NavController navController = Navigation.findNavController(view);
        // Database
        Database database = new Database(requireActivity());
        // Components
        Button register_button = view.findViewById(R.id.register_button);
        EditText register_username = view.findViewById(R.id.register_username);
        EditText register_password = view.findViewById(R.id.register_password);
        EditText register_email = view.findViewById(R.id.register_email);

        register_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Boolean valid = true;
                String username = register_username.getText().toString();
                String password = register_password.getText().toString();
                String email = register_email.getText().toString();

                if(!username.isEmpty() && !password.isEmpty() && !email.isEmpty()){
                    if(!FieldValidator.isValidUsername(username)){
                        displayUsernameRequirements(view);
                        valid = false;
                    }else{
                        TextView username_error_text_register = view.findViewById(R.id.username_error_text_register);
                        username_error_text_register.setText("");
                    }
                    if(!FieldValidator.isValidEmail(email)){
                        displayEmailRequirements(view);
                        valid = false;
                    }else {
                        TextView email_error_text_register = view.findViewById(R.id.email_error_text_register);
                        email_error_text_register.setText("");
                    }
                    if(!FieldValidator.isValidPassword(password)){
                        displayPasswordRequirements(view);
                        valid = false;
                    }else{
                        TextView password_error_text_register = view.findViewById(R.id.password_error_text_register);
                        password_error_text_register.setText("");
                    }
                    if(checkIfExists(database,username,email)){valid=false;}
                    if(valid){
                        database.addNewUser(new Usuario(username,password,email,false));
                        Toast.makeText(requireActivity(), "Usuario creado con éxito", Toast.LENGTH_SHORT).show();
                        navController.navigate(R.id.authenticationFragment);
                    }
                }
                else {
                    Toast.makeText(requireActivity(), "Rellene todos los campos", Toast.LENGTH_SHORT).show();
                }
            }
        });

        view.findViewById(R.id.backToLoginTextview).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.authenticationFragment);
            }
        });
    }

    /**
     * Display requirements for valid username input.
     *
     * @param view The current view.
     */
    private void displayUsernameRequirements(View view){
        TextView username_error_text_register = view.findViewById(R.id.username_error_text_register);
        username_error_text_register.setText(R.string.register_username_error_text);
    }

    /**
     * Display requirements for valid email input.
     *
     * @param view The current view.
     */
    private void displayEmailRequirements(View view){
        TextView email_error_text_register = view.findViewById(R.id.email_error_text_register);
        email_error_text_register.setText(R.string.register_email_error_text);
    }

    /**
     * Display requirements for valid password input.
     *
     * @param view The current view.
     */
    private void displayPasswordRequirements(View view){
        TextView password_error_text_register = view.findViewById(R.id.password_error_text_register);
        password_error_text_register.setText(R.string.register_password_error_text);
    }

    /**
     * Check if the user already exists in the database.
     *
     * @param database The database instance.
     * @param username The username to check.
     * @param email The email to check.
     * @return True if the user already exists, false otherwise.
     */
    private Boolean checkIfExists(Database database, String username, String email){
        if(database.getUserThroughUsername(username) != null){
            Toast.makeText(requireActivity(), "Nombre de usuario ya existente", Toast.LENGTH_SHORT).show();
            return true;
        }
        if(database.getUserThroughEmail(email) != null){
            Toast.makeText(requireActivity(), "El correo ya está en uso", Toast.LENGTH_SHORT).show();
            return true;
        }
        return false;
    }
}

/**
 *        ### Javadoc Explanation
 *
 *        - **Class-level comments** provide an overview of the class's purpose and its static map initialization.
 *        - **Method-level comments** explain the purpose, parameters, and return values of each method.
 *        - **Parameter tags (`@param`)** describe each method parameter.
 *        - **Return tags (`@return`)** describe what the method returns.
 */
