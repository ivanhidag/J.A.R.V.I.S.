package kowalsky.jarvis.system.bbdd;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import kowalsky.jarvis.system.jarvis.entities.Alarma;
import kowalsky.jarvis.system.jarvis.entities.Contact;
import kowalsky.jarvis.system.jarvis.entities.Usuario;
import kowalsky.jarvis.system.jarvis.libs.Values;

import java.util.ArrayList;
import java.util.List;

/**
 * Database helper class that manages database creation, version management,
 * and provides various database operations.
 */
public class Database extends SQLiteOpenHelper {

    // Database parameters
    private static final String DB_NAME = "kowalskybbdd";
    private static final int DB_VERSION = 1;
    // Table names
    private static final String USER_TABLE_NAME = "Usuarios";
    private static final String SESSION_TABLE_NAME = "Session";
    private static final String ALARM_TABLE_NAME = "Alarmas";
    private static final String CONTACT_TABLE_NAME = "Contactos";

    /**
     * Constructor for the Database class.
     *
     * @param context the context in which the database is created or accessed.
     */
    public Database(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String tabla_usuarios = "create table " + USER_TABLE_NAME + " ("
                + "Id_usuario" + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "Username" + " TEXT,"
                + "Password" + " TEXT,"
                + "Email" + " TEXT,"
                + "Administrador" + " BOOLEAN"+")";

        String tabla_session = "create table " + SESSION_TABLE_NAME + " ("
                + "Id_Session" + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "Username" + " TEXT,"
                + "Password" + " TEXT,"
                + "Logged" + " BOOLEAN"+")";

        String tabla_alarmas = "create table " + ALARM_TABLE_NAME + " ("
                + "Id_alarma" + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "Titulo" + " TEXT,"
                + "Tipo" + " TEXT,"
                + "Autor" + " TEXT,"
                + "Hora" + " INTEGER,"
                + "Minutos" + " INTEGER"+")";

        String tabla_contactos = "create table " + CONTACT_TABLE_NAME + " ("
                + "Id_contacto" + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + "Nombre" + " TEXT,"
                + "Telefono" + " TEXT"+")";

        db.execSQL(tabla_usuarios);
        db.execSQL(tabla_session);
        db.execSQL(tabla_alarmas);
        db.execSQL(tabla_contactos);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

    /**
     * Adds a new contact to the Contactos table.
     *
     * @param contact the Contact object to be added.
     */
    public void addNewContact(Contact contact){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Nombre",contact.getContactname());
        values.put("Telefono",contact.getContactnumber());
        db.insert(CONTACT_TABLE_NAME, null, values);
        db.close();
    }

    /**
     * Adds a super administrator to the Usuarios table.
     */
    public void addSuperAdminnistrator(){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Username", Values.SUPER_ADMINISTRATOR_USERNAME);
        values.put("Password",Values.SUPER_ADMINISTRATOR_PASSWORD);
        values.put("Email", Values.SUPER_ADMINISTRATOR_EMAIL);
        values.put("Administrador", true);
        db.insert(USER_TABLE_NAME, null, values);
        db.close();
    }

    /**
     * Retrieves a contact from the Contactos table based on the contact name.
     *
     * @param contactname the name of the contact to retrieve.
     * @return the Contact object if found, null otherwise.
     */
    public Contact getContact(String contactname){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("select * from "+ CONTACT_TABLE_NAME, null);
        if (c.moveToFirst()){
            do {
                if(c.getString(1).equalsIgnoreCase(contactname)){
                    return new Contact(c.getString(1),c.getString(2));
                }
            } while(c.moveToNext());
        }
        c.close();
        return null;
    }

    /**
     * Deletes a contact from the Contactos table.
     *
     * @param contact the Contact object to be deleted.
     */
    public void deleteContact(Contact contact) {
        SQLiteDatabase db = this.getReadableDatabase();
        db.delete(CONTACT_TABLE_NAME, "Nombre" + "=?", new String[]{"" + contact.getContactname()});
        db.close();
    }

    /**
     * Logs in a user by adding their session information to the Session table.
     *
     * @param username the username of the user.
     * @param password the password of the user.
     */
    public void logIn(String username, String password){
        SQLiteDatabase db = this.getWritableDatabase();

        db.execSQL("Delete from "+SESSION_TABLE_NAME+" where Id_Session IN (Select Id_Session from "+SESSION_TABLE_NAME+" limit 1);");

        ContentValues values = new ContentValues();
        values.put("Logged",true);
        values.put("Username",username);
        values.put("Password",password);
        db.insert(SESSION_TABLE_NAME, null, values);
        db.close();
    }

    /**
     * Retrieves the currently logged user from the Session table.
     *
     * @return the Usuario object of the currently logged user, or null if no user is logged in.
     */
    public Usuario getCurrentLoggedUser(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("select * from "+SESSION_TABLE_NAME, null);
        if (c.moveToFirst()){
            do {
                Usuario user = new Usuario(c.getString(1),c.getString(2), c.getString(3), c.getInt(4)>0);
                user.setId(c.getString(0));
                return user;
            } while(c.moveToNext());
        }
        c.close();
        return null;
    }

    /**
     * Logs out the current user by deleting their session information from the Session table.
     */
    public void logOut(){
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("Delete from "+SESSION_TABLE_NAME+" where Id_Session IN (Select Id_Session from "+SESSION_TABLE_NAME+" limit 1);");
        db.close();
    }

    /**
     * Checks if there is any user currently logged in.
     *
     * @return true if there is a logged-in user, false otherwise.
     */
    public boolean isLogged() {
        SQLiteDatabase db = null;
        Cursor cursor = null;
        boolean hasEntries = false;

        try {
            db = this.getReadableDatabase();
            cursor = db.rawQuery("SELECT 1 FROM " + SESSION_TABLE_NAME + " LIMIT 1", null);

            if (cursor != null && cursor.moveToFirst()) {
                hasEntries = true;
            }
        } catch (Exception e) {
            // Handle exception
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            if (db != null) {
                db.close();
            }
        }

        return hasEntries;
    }

    /**
     * Adds a new user to the Usuarios table.
     *
     * @param user the Usuario object to be added.
     */
    public void addNewUser(Usuario user){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Username",user.getUsername());
        values.put("Password",user.getPassword());
        values.put("Email",user.getEmail());
        values.put("Administrador",user.getAdministrator());
        db.insert(USER_TABLE_NAME, null, values);
        db.close();
    }

    /**
     * Retrieves a user from the Usuarios table based on the username.
     *
     * @param username the username of the user to retrieve.
     * @return the Usuario object if found, null otherwise.
     */
    public Usuario getUserThroughUsername(String username){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("select * from "+USER_TABLE_NAME, null);
        if (c.moveToFirst()){
            do {
                if(c.getString(1).equals(username)){
                    Usuario user = new Usuario(c.getString(1),c.getString(2),c.getString(3),c.getInt(4)>0);
                    user.setId(c.getString(0));
                    return user;
                }
            } while(c.moveToNext());
        }
        c.close();
        return null;
    }

    /**
     * Retrieves a user from the Usuarios table based on the email.
     *
     * @param email the email of the user to retrieve.
     * @return the Usuario object if found, null otherwise.
     */
    public Usuario getUserThroughEmail(String email){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("select * from "+USER_TABLE_NAME, null);
        if (c.moveToFirst()){
            do {
                if(c.getString(3).equals(email)){
                    Usuario user = new Usuario(c.getString(1),c.getString(2),c.getString(3),c.getInt(4)>0);
                    user.setId(c.getString(0));
                    return user;
                }
            } while(c.moveToNext());
        }
        c.close();
        return null;
    }

    /**
     * Checks if the username and password match a user in the database.
     *
     * @param username the username to check.
     * @param password the password to check.
     * @return -1 if there's no match, 0 if only the username matches, and 1 if there is a full match.
     */
    public int checkUser(String username, String password){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("select * from "+USER_TABLE_NAME, null);
        if (c.moveToFirst()){
            do {
                if(c.getString(1).equals(username)){
                    if(c.getString(2).equals(password)){
                        return 1;
                    }
                    return 0;
                }
            } while(c.moveToNext());
        }
        c.close();
        return -1;
    }

    /**
     * Retrieves a list of all users from the Usuarios table.
     *
     * @return an ArrayList of Usuario objects.
     */
    public ArrayList<Usuario> getUserList(){
        ArrayList<Usuario> content = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor c = db.rawQuery("select * from "+USER_TABLE_NAME, null);
        if (c.moveToFirst()){
            do {
                Usuario user = new Usuario(c.getString(1),c.getString(2),c.getString(3),c.getInt(4)>0);
                user.setId(c.getString(0));
                content.add(user);
            } while(c.moveToNext());
            return content;
        }
        c.close();
        return null;
    }

    /**
     * Retrieves all contact names from the Contactos table.
     *
     * @return a list of all contact names.
     */
    public List<String> getAllContactNames() {
        List<String> contactNames = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(CONTACT_TABLE_NAME, new String[]{"Nombre"}, null, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                String name = cursor.getString(cursor.getColumnIndexOrThrow("Nombre"));
                contactNames.add(name);
            }
            cursor.close();
        }
        return contactNames;
    }

    /**
     * Deletes a user from the Usuarios table.
     *
     * @param user the Usuario object to be deleted.
     */
    public void deleteUser(Usuario user){
        SQLiteDatabase db = this.getReadableDatabase();
        db.delete(USER_TABLE_NAME, "Username" + "=?", new String[]{""+user.getUsername()});
        db.close();
    }

    /**
     * Adds a new alarm to the Alarmas table.
     *
     * @param alarma the Alarma object to be added.
     */
    public void añadirAlarma(Alarma alarma){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Titulo",alarma.getTitulo());
        values.put("Tipo",alarma.getTipo());
        values.put("Autor",alarma.getAutor());
        values.put("Hora",alarma.getHora());
        values.put("Minutos",alarma.getMinutos());
        db.insert(ALARM_TABLE_NAME, null, values);
        db.close();
    }

    /**
     * Deletes an alarm from the Alarmas table.
     *
     * @param alarma the Alarma object to be deleted.
     */
    public void deleteAlarm(Alarma alarma){
        SQLiteDatabase db = this.getReadableDatabase();
        db.delete(
                // Table name
                ALARM_TABLE_NAME,

                // Where clause
                "Autor = ? AND Hora = ? AND Minutos = ?",

                // Where Args
                new String[]{
                        alarma.getAutor(),
                        String.valueOf(alarma.getHora()),
                        String.valueOf(alarma.getMinutos())
                }
        );
        db.close();
    }

    /**
     * Deletes all rows from a specified table.
     *
     * @param tableName the name of the table from which to delete all rows.
     */
    public void deleteAllRows(String tableName) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = null;
        try {
            // Query to count the number of rows in the table
            String countQuery = "SELECT COUNT(*) FROM " + tableName;
            cursor = db.rawQuery(countQuery, null);
            if (cursor != null && cursor.moveToFirst()) {
                int rowCount = cursor.getInt(0); // Get the count of rows
                if (rowCount > 0) {
                    // If there are rows, delete all of them
                    String deleteAllSQL = "DELETE FROM " + tableName;
                    db.execSQL(deleteAllSQL);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (cursor != null) {
                cursor.close();
            }
            db.close();
        }
    }

    /**
     * Drops a specified table from the database.
     *
     * @param tableName the name of the table to be dropped.
     */
    public void dropTable(String tableName) {
        SQLiteDatabase db = this.getWritableDatabase();
        try {
            String dropTableSQL = "DROP TABLE IF EXISTS " + tableName;
            db.execSQL(dropTableSQL);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            db.close();
        }
    }
}
