package kowalsky.jarvis.system.modules.system_modules;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;

import androidx.core.app.ActivityCompat;

import java.util.ArrayList;
import java.util.List;

/**
 * PermissionHelper is a utility class for managing runtime permissions in an Android application.
 */
public class PermissionHelper {

    private static final int PERMISSION_REQUEST_CODE = 100;
    private Context context;
    private String[] permissions;

    /**
     * Constructs a new PermissionHelper with the given context.
     *
     * @param context The context to be used for checking and requesting permissions.
     */
    public PermissionHelper(Context context) {
        this.context = context;
        this.permissions = new String[]{
                Manifest.permission.POST_NOTIFICATIONS,
                Manifest.permission.FOREGROUND_SERVICE,
                Manifest.permission.FOREGROUND_SERVICE_MICROPHONE,
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.INTERNET,
                Manifest.permission.RECEIVE_BOOT_COMPLETED,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.WRITE_CONTACTS,
                Manifest.permission.WRITE_EXTERNAL_STORAGE,
                Manifest.permission.MANAGE_EXTERNAL_STORAGE,
                Manifest.permission.SEND_SMS,
                Manifest.permission.SCHEDULE_EXACT_ALARM,
                Manifest.permission.USE_EXACT_ALARM,
                Manifest.permission.DISABLE_KEYGUARD,
                Manifest.permission.WAKE_LOCK,
                Manifest.permission.REQUEST_DELETE_PACKAGES
        };
    }

    /**
     * Checks and requests permissions continuously until all are granted.
     */
    public void requestPermissions() {
        List<String> permissionsNeeded = new ArrayList<>();

        // Check for each permission and add to the list if not granted
        for (String permission : permissions) {
            if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                permissionsNeeded.add(permission);
            }
        }

        // If permissionsNeeded is not empty, request permissions
        if (!permissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions((Activity) context, permissionsNeeded.toArray(new String[0]), PERMISSION_REQUEST_CODE);
        }
    }

    /**
     * Checks if all permissions are granted.
     *
     * @return True if all permissions are granted, false otherwise.
     */
    public boolean allPermissionsGranted() {
        for (String permission : permissions) {
            if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                return false;
            }
        }
        return true;
    }
}
