package kowalsky.jarvis.system.modules.action_management;

import android.content.Context;
import android.util.Log;

import kowalsky.jarvis.system.MainActivity;
import kowalsky.jarvis.system.jarvis.core.CoreResponseListener;
import kowalsky.jarvis.system.jarvis.core.CoreTask;
import kowalsky.jarvis.system.modules.system_modules.AudioHelper;

/**
 * Helper class for setting the volume based on the response received.
 */
public class SetVolume implements CoreResponseListener {

    private Context context;

    /**
     * Constructor for the SetVolume class.
     *
     * @param context The context of the application.
     */
    public SetVolume(Context context){
        this.context = context;
    }

    /**
     * Gets the volume level based on the last query.
     *
     * @param lastquery The last query received.
     */
    public void get_volume_level(String lastquery){
        try {
            CoreTask.rawQuery(
                    "Basándote en el siguiente texto ¿Tengo que bajar o subir el volumen?" +
                            "(response en máximo 3 palabras). " +
                            "El texto: "+lastquery,
                    SetVolume.this);
        } catch (NullPointerException exception){
            Log.e("ResponderAction","ResponderAction: query null o vacia");
        }
    }

    /**
     * Handles the response received.
     *
     * @param result The response received from the Jarvis system.
     */
    @Override
    public void onResponseReceived(String result) {
        try {
            MainActivity.SystemPost.setValue(result);
            AudioHelper audioHelper = new AudioHelper(this.context);
            if(result.toLowerCase().contains("bajar")){audioHelper.lowerVolume();}
            if(result.toLowerCase().contains("subir")){audioHelper.raiseVolume();}
        } catch (NullPointerException exception){
            Log.e("ResponderAction","ResponderAction: result null o vacio");
        }
    }
}
