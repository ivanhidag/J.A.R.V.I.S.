package kowalsky.jarvis.system.modules.text_processing;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Utility class for translating words representing numbers into their numerical representations.
 */
public class NumberTranslator {
    // Mapping of words to numbers
    private static final Map<String, String> NUMBER_MAP = new HashMap<>();

    static {
        // Add mapping of words to numbers
        NUMBER_MAP.put("cero", "0");
        NUMBER_MAP.put("uno", "1");
        NUMBER_MAP.put("dos", "2");
        NUMBER_MAP.put("tres", "3");
        NUMBER_MAP.put("cuatro", "4");
        NUMBER_MAP.put("cinco", "5");
        NUMBER_MAP.put("seis", "6");
        NUMBER_MAP.put("siete", "7");
        NUMBER_MAP.put("ocho", "8");
        NUMBER_MAP.put("nueve", "9");
        NUMBER_MAP.put("diez", "10");
        NUMBER_MAP.put("once", "11");
        NUMBER_MAP.put("doce", "12");
        NUMBER_MAP.put("trece", "13");
        NUMBER_MAP.put("catorce", "14");
        NUMBER_MAP.put("quince", "15");
        NUMBER_MAP.put("dieciséis", "16");
        NUMBER_MAP.put("diecisiete", "17");
        NUMBER_MAP.put("dieciocho", "18");
        NUMBER_MAP.put("diecinueve", "19");
        NUMBER_MAP.put("veinte", "20");
        NUMBER_MAP.put("treinta", "30");
        NUMBER_MAP.put("cuarenta", "40");
        NUMBER_MAP.put("cincuenta", "50");
        NUMBER_MAP.put("sesenta", "60");
        NUMBER_MAP.put("setenta", "70");
        NUMBER_MAP.put("ochenta", "80");
        NUMBER_MAP.put("noventa", "90");
        NUMBER_MAP.put("cien", "100");
        NUMBER_MAP.put("mil", "1000");
    }

    /**
     * Translates words representing numbers into their numerical representations.
     *
     * @param input the input string containing words representing numbers
     * @return the input string with words replaced by their numerical representations
     */
    public static String translateNumbers(String input) {
        // Regular expression to find numbers written in words
        String regex = "\\b(" + String.join("|", NUMBER_MAP.keySet()) + ")\\b";

        // Compile the regular expression
        Pattern pattern = Pattern.compile(regex, Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(input);

        StringBuffer result = new StringBuffer();
        // Replace the found words with their corresponding numbers
        while (matcher.find()) {
            matcher.appendReplacement(result, NUMBER_MAP.get(matcher.group().toLowerCase()));
        }
        matcher.appendTail(result);

        return result.toString();
    }
}
