package kowalsky.jarvis.system.jarvis.libs;

/**
 * The SystemKey class provides constants for system-related key codes.
 */
public class SystemKey {

    /**
     * Key code for app request.
     */
    public static final String APP_REQUEST_CODE = "ARC";

    /**
     * Key code for cancel request.
     */
    public static final String CANCEL_REQUEST_CODE = "CRC";
}
