package kowalsky.jarvis.system.jarvis.libs;

/**
 * The Values class provides constants for various system values.
 */
public class Values {

    /**
     * Package name of the application.
     */
    public static final String APP_PACKAGE_NAME = "com.example.justaratherveryintelligentsystembetaversion";

    /**
     * Username for the super administrator.
     */
    public static final String SUPER_ADMINISTRATOR_USERNAME = "SuperAdminKP";

    /**
     * Password for the super administrator.
     */
    public static final String SUPER_ADMINISTRATOR_PASSWORD = "SuperAdminKP";

    /**
     * Email for the super administrator.
     */
    public static final String SUPER_ADMINISTRATOR_EMAIL = "info@jarvis.com";

    /**
     * Maximum integer value.
     */
    public static final int INT_MAX_VALUE = 999999999;

    /**
     * Keyboard height in pixels.
     */
    public static final int KEYBOARD_HEIGHT_IN_PX = 1008;

    /**
     * Keyboard height in density-independent pixels (dp).
     */
    public static final int KEYBOARD_HEIGHT_IN_DP = 336;
}
