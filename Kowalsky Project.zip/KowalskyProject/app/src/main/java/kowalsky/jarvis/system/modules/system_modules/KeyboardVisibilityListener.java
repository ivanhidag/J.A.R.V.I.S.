package kowalsky.jarvis.system.modules.system_modules;

import android.app.Activity;
import android.graphics.Rect;
import android.view.View;
import android.view.ViewTreeObserver;

/**
 * KeyboardVisibilityListener is a utility class for detecting changes in keyboard visibility.
 */
public class KeyboardVisibilityListener {

    /**
     * Interface definition for a callback to be invoked when the keyboard visibility changes.
     */
    public interface OnKeyboardVisibilityListener {
        /**
         * Called when the keyboard visibility changes.
         *
         * @param visible True if the keyboard is visible, false otherwise.
         */
        void onVisibilityChanged(boolean visible);
    }

    /**
     * Sets a listener to be notified about changes in keyboard visibility.
     *
     * @param activity The activity in which the keyboard visibility is being monitored.
     * @param listener The listener to notify.
     */
    public static void setKeyboardVisibilityListener(Activity activity, final OnKeyboardVisibilityListener listener) {
        final View rootView = activity.findViewById(android.R.id.content);
        rootView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
            private boolean isKeyboardVisible;

            @Override
            public void onGlobalLayout() {
                Rect r = new Rect();
                rootView.getWindowVisibleDisplayFrame(r);
                int screenHeight = rootView.getRootView().getHeight();
                int keypadHeight = screenHeight - r.bottom;

                // 0.15 ratio is perhaps enough to determine keypad height.
                boolean isKeyboardNowVisible = keypadHeight > screenHeight * 0.15;

                if (isKeyboardNowVisible != isKeyboardVisible) {
                    isKeyboardVisible = isKeyboardNowVisible;
                    listener.onVisibilityChanged(isKeyboardVisible);
                }
            }
        });
    }
}
