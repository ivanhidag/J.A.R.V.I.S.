package kowalsky.jarvis.system.modules.text_processing;

import java.text.Normalizer;

import kowalsky.jarvis.system.jarvis.libs.speechanalyzer.AnalyzerRegex;

/**
 * Utility class for analyzing speech input.
 */
public class SpeechAnalyzer {

    /**
     * Translates words representing numbers into their numerical representations.
     *
     * @param speech the input speech string containing words representing numbers
     * @return the input string with words replaced by their numerical representations
     */
    public static String regexNumbers(String speech){
        return NumberTranslator.translateNumbers(speech);
    }

    /**
     * Translates phrases representing hours into their standard time format.
     *
     * @param speech the input speech string containing phrases representing hours
     * @return the input string with phrases replaced by their standard time format
     */
    public static String regexHours(String speech){
        return HourTranslator.translateHour(speech);
    }

    /**
     * Removes articles from the input speech.
     *
     * @param speech the input speech string containing articles
     * @return the input string with articles removed
     */
    public static String regexArticles(String speech){
        for(int i = 0; i< AnalyzerRegex.REGEX_ARTICLES.size(); i++){
            speech = speech.replaceAll("\\b"+AnalyzerRegex.REGEX_ARTICLES.get(i)+"\\b\\s*", "");
        }
        return speech;
    }

    /**
     * Removes accents from the input speech.
     *
     * @param speech the input speech string containing accents
     * @return the input string with accents removed
     */
    public static String regexAccents(String speech){
        for(int i=0;i<AnalyzerRegex.REGEX_ACCENTS.size();i++){
            speech = speech.replaceAll(AnalyzerRegex.REGEX_ACCENTS.get(i)[0], AnalyzerRegex.REGEX_ACCENTS.get(i)[1]);
        }
        return speech;
    }

    /**
     * Normalizes the input text by converting it to lowercase and removing diacritics.
     *
     * @param texto the input text to be normalized
     * @return the normalized text
     */
    public static String normalizarTexto(String texto) {
        // Convertir el texto a minúsculas
        texto = texto.toLowerCase();

        // Normalizar el texto y eliminar los diacríticos
        texto = Normalizer.normalize(texto, Normalizer.Form.NFD);
        texto = texto.replaceAll("\\p{InCombiningDiacriticalMarks}+", "");

        return texto;
    }

    /**
     * Determines the start position of the content in the speech.
     *
     * @param speech the input speech string
     * @return the start position of the content, or -1 if not found
     */
    private static int getContentStartPos(String speech){
        speech = speech.toLowerCase();
        for(int i=0;i<AnalyzerRegex.JARVIS_NAMES.size();i++){
            if(speech.contains(AnalyzerRegex.JARVIS_NAMES.get(i))){
                return speech.indexOf(AnalyzerRegex.JARVIS_NAMES.get(i))+AnalyzerRegex.JARVIS_NAMES.get(i).length();
            }
        }
        return -1;
    }

    /**
     * Extracts the content from the speech, excluding the wake word.
     *
     * @param speech the input speech string
     * @return the content of the speech, or null if not found
     */
    public static String getSpeechContent(String speech) {
        if(getContentStartPos(speech) != -1 && getContentStartPos(speech) < speech.length() && !speech.trim().isEmpty()){
            return speech.substring(getContentStartPos(speech));
        }
        return null;
    }

    /**
     * Checks if the speech contains the wake word.
     *
     * @param speech the input speech string
     * @return true if the speech contains the wake word, false otherwise
     */
    public static Boolean containsKey(String speech){
        for(int i=0;i<AnalyzerRegex.JARVIS_NAMES.size();i++){
            if(speech.contains(AnalyzerRegex.JARVIS_NAMES.get(i))){
                return true;
            }
        }
        return false;
    }
}
