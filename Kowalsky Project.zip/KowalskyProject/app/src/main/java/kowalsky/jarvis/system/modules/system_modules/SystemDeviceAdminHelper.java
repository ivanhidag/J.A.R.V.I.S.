package kowalsky.jarvis.system.modules.system_modules;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * SystemDeviceAdminHelper is a utility class for managing device administrator permissions and actions.
 */
public class SystemDeviceAdminHelper {

    private static final int REQUEST_CODE_ENABLE_ADMIN = 1;
    private DevicePolicyManager devicePolicyManager;
    private ComponentName deviceAdminReceiver;
    private Context context;

    /**
     * Constructs a new SystemDeviceAdminHelper with the given context, device policy manager, and device admin receiver.
     *
     * @param context            The context to be used for accessing system services and resources.
     * @param devicePolicyManager The device policy manager instance.
     * @param deviceAdminReceiver The device admin receiver component.
     */
    public SystemDeviceAdminHelper(Context context, DevicePolicyManager devicePolicyManager, ComponentName deviceAdminReceiver) {
        this.context = context;
        this.deviceAdminReceiver = deviceAdminReceiver;
        this.devicePolicyManager = devicePolicyManager;
    }

    /**
     * Requests device admin permission from the user.
     */
    public void requestDeviceAdminPermission() {
        Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, deviceAdminReceiver);
        intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Additional text explaining why we need this permission");

        // Check if the context is an Activity before starting the activity for result
        if (context instanceof Activity) {
            ((Activity) context).startActivityForResult(intent, REQUEST_CODE_ENABLE_ADMIN);
        } else {
            context.startActivity(intent);
        }
    }

    /**
     * Programmatically locks the device.
     */
    public void lockDevice() {
        if (devicePolicyManager.isAdminActive(deviceAdminReceiver)) {
            devicePolicyManager.lockNow();
        } else {
            Log.e("SystemDeviceAdminHelper", "Device admin permission not granted");
        }
    }
}
