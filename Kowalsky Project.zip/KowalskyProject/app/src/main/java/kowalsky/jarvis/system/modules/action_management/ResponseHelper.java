package kowalsky.jarvis.system.modules.action_management;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.util.Log;

import kowalsky.jarvis.system.jarvis.core.CoreTask;
import kowalsky.jarvis.system.modules.system_modules.AudioHelper;
import kowalsky.jarvis.system.modules.system_modules.SystemDeviceAdminHelper;
import kowalsky.jarvis.system.modules.system_modules.SystemDeviceAdminReceiver;
import kowalsky.jarvis.system.modules.telephony_module.PhoneCall;
import kowalsky.jarvis.system.modules.text_processing.SpeechAnalyzer;

/**
 * Helper class for managing responses based on core responses.
 */
public class ResponseHelper {

    /**
     * Manages the response based on the core response received.
     *
     * @param context      The context of the application.
     * @param CoreResponse The core response received from the Jarvis system.
     */
    public static void manageResponse(Context context, String CoreResponse) {
        try {
            if (CoreResponse != null) {
                switch (CoreResponse) {
                    case "mute_system":
                        new AudioHelper(context).muteApp();
                        break;
                    case "unmute_system":
                        new AudioHelper(context).unmuteApp();
                        break;
                    case "set_alarm":
                        // Perform action for set_alarm
                        // Add your code here
                        break;
                    case "phone_call":
                        PhoneCall phoneCall = new PhoneCall(context);
                        phoneCall.get_contact_data(CoreTask.getLastQuery());
                        break;
                    case "suspend_phone":
                        DevicePolicyManager devicePolicyManager = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
                        ComponentName deviceAdminReceiver = new ComponentName(context, SystemDeviceAdminReceiver.class);

                        SystemDeviceAdminHelper systemDeviceAdminHelper = new SystemDeviceAdminHelper(context, devicePolicyManager, deviceAdminReceiver);
                        systemDeviceAdminHelper.lockDevice();
                        break;
                    case "search_route":
                        // Perform action for search_route
                        // Add your code here
                        break;
                    case "send_email":
                        // Perform action for send_email
                        // Add your code here
                        break;
                    case "play_music":
                        // Perform action for play_music
                        // Add your code here
                        break;
                    case "send_message":
                        // Perform action for send_message
                        // Add your code here
                        break;
                    case "set_volume":
                        SetVolume volumeSetter = new SetVolume(context);
                        volumeSetter.get_volume_level(CoreTask.getLastQuery());
                        break;
                    case "answer_question":
                        String last_query = SpeechAnalyzer.regexAccents(CoreTask.getLastQuery());
                        if(last_query.contains("mas informacion"))
                        {new AnswerQuestion().large_response(CoreTask.getLastQuery());}
                        else {new AnswerQuestion().respond(CoreTask.getLastQuery());}
                        break;
                    case "saludar":
                        new AnswerQuestion().respond(CoreTask.getLastQuery());
                        break;
                    default:
                        // do nothing --
                        break;
                }
            } else {
                Log.e("ResponseManager", "manageResponse: Unrecognized CoreResponse");
            }
        } catch (NullPointerException exception) {
            Log.e("ResponseManager", "manageResponse: CoreResponse null or empty");
        }
    }
}
