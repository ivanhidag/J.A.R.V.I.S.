package kowalsky.jarvis.system.modules.text_processing;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Utility class for translating and processing hours in text.
 */
public class HourTranslator {

    /**
     * Translates hours in text from natural language to digital format.
     *
     * @param inputStr the input text containing hours in natural language
     * @return the translated text with hours in digital format
     */
    public static String translateHour(String inputStr) {
        String output = inputStr;

        Matcher matcher = Pattern.compile("\\b(\\d+) y media\\b").matcher(inputStr);
        while (matcher.find()) {
            String matchedNumber = matcher.group(1); // Extract the matched number
            if(Integer.parseInt(matchedNumber) >= 0 && Integer.parseInt(matchedNumber) <= 24){
                output = output.replaceAll(matchedNumber + " y media", matchedNumber + ":30");
            }
        }

        matcher = Pattern.compile("\\b(\\d+) y cuarto\\b").matcher(inputStr);
        while (matcher.find()) {
            String matchedNumber = matcher.group(1); // Extract the matched number
            if(Integer.parseInt(matchedNumber) >= 0 && Integer.parseInt(matchedNumber) <= 24) {
                output = output.replaceAll(matchedNumber + " y cuarto", matchedNumber + ":15");
            }
        }

        matcher = Pattern.compile("\\b(\\d+) menos cuarto\\b").matcher(inputStr);
        while (matcher.find()) {
            String matchedNumber = matcher.group(1); // Extract the matched number
            if(Integer.parseInt(matchedNumber) >= 0 && Integer.parseInt(matchedNumber) <= 24){
                int outputNum = Integer.parseInt(matchedNumber) - 1;
                output = output.replaceAll(matchedNumber + " menos cuarto", outputNum + ":45");
            }
        }

        matcher = Pattern.compile("\\b(\\d+) y (\\d+)\\b").matcher(inputStr);
        while (matcher.find()) {
            String matchedNumber1 = matcher.group(1); // Extract the matched number
            String matchedNumber2 = matcher.group(2); // Extract the matched number
            if (
                    Integer.parseInt(matchedNumber1) >= 0 && Integer.parseInt(matchedNumber1) <= 24
                            && Integer.parseInt(matchedNumber2) >= 0 && Integer.parseInt(matchedNumber2) <= 24
            ) {
                output = output.replaceAll(matchedNumber1 + " y " + matchedNumber2, matchedNumber1 + ":" + matchedNumber2);
            }
        }
        return output;
    }

    /**
     * Checks if the input string contains a valid hour in digital format.
     *
     * @param inputStr the input text to check for an hour
     * @return the hour in digital format if found, null otherwise
     */
    public static String containsHour(String inputStr){
        Matcher matcher = Pattern.compile("\\b(\\d+):(\\d+)\\b").matcher(inputStr);
        if(matcher.find()) {
            String matchedNumber1 = matcher.group(1); // Extract the matched number
            String matchedNumber2 = matcher.group(2); // Extract the matched number
            return matchedNumber1+":"+matchedNumber2;
        }
        return null;
    }

    /**
     * Checks if the input string represents a valid hour in digital format.
     *
     * @param inputStr the input text to check for an hour
     * @return true if the input string represents a valid hour, false otherwise
     */
    public static Boolean isHour(String inputStr){
        Matcher matcher = Pattern.compile("(\\d+):(\\d+)").matcher(inputStr);
        return matcher.find();
    }
}
