package kowalsky.jarvis.system.modules.system_modules;

import android.widget.ScrollView;

/**
 * AutoScroller is a utility class for automatically scrolling a ScrollView to the bottom.
 */
public class AutoScroller {

    /**
     * Scrolls the given ScrollView to the bottom.
     *
     * @param scrollView The ScrollView to be scrolled.
     */
    public static void scroll(ScrollView scrollView){
        scrollView.post(new Runnable() {
            @Override
            public void run() {
                scrollView.fullScroll(ScrollView.FOCUS_DOWN);
            }
        });
    }
}
