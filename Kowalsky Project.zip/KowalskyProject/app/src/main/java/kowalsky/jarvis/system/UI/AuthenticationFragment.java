package kowalsky.jarvis.system.UI;

import android.annotation.SuppressLint;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import kowalsky.jarvis.system.bbdd.Database;
import kowalsky.jarvis.system.modules.telephony_module.ContacHelper;
import kowalskyproject.jarvis.system.R;

/**
 * A fragment for user authentication.
 */
public class AuthenticationFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    public AuthenticationFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment AuthenticationFragment.
     */
    public static AuthenticationFragment newInstance(String param1, String param2) {
        AuthenticationFragment fragment = new AuthenticationFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_authentication, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // Navigation instance
        NavController navController = Navigation.findNavController(view);
        // Database instance
        Database db = new Database(requireActivity());

        // Check if logged in, then redirect to home
        if (db.isLogged()) {
            navController.navigate(R.id.homeFragment);
        }

        // Components
        TextView register_link_textview = view.findViewById(R.id.register_link_textview);
        EditText login_username = view.findViewById(R.id.login_username);
        EditText login_password = view.findViewById(R.id.login_password);
        Button login_button = view.findViewById(R.id.login_button);

        login_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = login_username.getText().toString();
                String password = login_password.getText().toString();
                if (!username.trim().isEmpty() && !password.trim().isEmpty()) {
                    if (userInDatabase(view, username, password)) {
                        db.logIn(username, password);
                        ContacHelper.retriveContactAgenda(requireActivity());
                        navController.navigate(R.id.homeFragment);
                    }
                } else {
                    Toast.makeText(requireActivity(), "Rellene todos los campos", Toast.LENGTH_SHORT).show();
                }
            }
        });

        register_link_textview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                navController.navigate(R.id.registerFragment);
            }
        });

    }

    /**
     * Checks if the user exists in the database and displays appropriate error messages.
     *
     * @param view     the current view
     * @param username the username
     * @param password the password
     * @return true if the user exists, false otherwise
     */
    @SuppressLint("SetTextI18n")
    private Boolean userInDatabase(View view, String username, String password) {
        Database database = new Database(requireActivity());
        switch (database.checkUser(username, password)) {
            case 1:
                return true;
            case 0:
                ((TextView) view.findViewById(R.id.login_password)).setText("*La contraseña no es correcta");
                ((TextView) view.findViewById(R.id.login_username)).setText("");
                break;
            case -1:
                ((TextView) view.findViewById(R.id.login_password)).setText("*La contraseña no es correcta");
                ((TextView) view.findViewById(R.id.login_username)).setText("*El usuario no es correcto");
                break;
        }
        return false;
    }
}