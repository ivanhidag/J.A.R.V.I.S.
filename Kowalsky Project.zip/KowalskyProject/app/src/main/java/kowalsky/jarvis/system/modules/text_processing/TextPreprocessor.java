package kowalsky.jarvis.system.modules.text_processing;

import java.text.Normalizer;
import java.util.regex.Pattern;

/**
 * Utility class for preprocessing text.
 */
public class TextPreprocessor {

    /**
     * Preprocesses the input text by converting it to lowercase, removing punctuation and special characters,
     * and removing accents.
     *
     * @param text the input text to be preprocessed
     * @return the preprocessed text
     */
    public static String preprocessText(String text) {
        // Convert to lowercase
        text = text.toLowerCase();

        // Remove punctuation and special characters
        text = text.replaceAll("[^\\p{L}\\p{Nd}\\s]", "");

        // Remove accents and normalize
        text = Normalizer.normalize(text, Normalizer.Form.NFD);
        Pattern pattern = Pattern.compile("\\p{InCombiningDiacriticalMarks}+");
        text = pattern.matcher(text).replaceAll("");

        return text;
    }
}
