package kowalsky.jarvis.system.jarvis.core.service;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.app.Service;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.media.AudioManager;
import android.os.Build;
import android.os.IBinder;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import kowalsky.jarvis.system.MainActivity;
import kowalsky.jarvis.system.jarvis.core.speechrecognizer.SpeechRecognizerModel;
import kowalskyproject.jarvis.system.R;

/**
 * BackgroundService is a foreground service that handles speech recognition
 * and displays a persistent notification.
 */
public class BackgroundService extends Service {

    private final int NOTIFICATION_ID = 1;
    private final String CHANNEL_ID = "100";
    private final String CHANNEL_NAME = "Foreground Notification";
    private SpeechRecognizerModel speechRecognizer;

    /**
     * Default constructor for BackgroundService.
     */
    public BackgroundService(){
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Starts the service and creates the notification
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                    NOTIFICATION_ID,
                    showNotification("Haga click para volver a la aplicación."),
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            );
        }

        // Creates speech recognition
        speechRecognizer = new SpeechRecognizerModel(BackgroundService.this);
        // Sets up speech recognizer
        speechRecognizer.create();
        // Starts speech recognition
        speechRecognizer.start();
        return START_STICKY;
    }

    /**
     * Displays a notification with the given content.
     *
     * @param content the content to display in the notification.
     * @return the created Notification object.
     */
    @SuppressLint("NotificationTrampoline")
    private Notification showNotification(String content) {

        // Create Notification Channel
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ((NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(
                    new NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH)
            );
        }

        // Create notification
        NotificationCompat.Builder notification = new NotificationCompat.Builder(this, CHANNEL_ID);
        // Set title
        notification.setContentTitle("Running Jarvis...");
        // Set content
        notification.setContentText(content);
        // Set icon
        notification.setSmallIcon(R.drawable.logo_aeioros_negro_limpio);
        // Set persistent
        notification.setOngoing(true);

        // Set notification pressed ACTION
        Intent notificationIntent = new Intent(this, MainActivity.class);
        // Calls MainActivity
        notificationIntent.setAction(Intent.ACTION_MAIN);
        // Adds launcher permission
        notificationIntent.addCategory(Intent.CATEGORY_LAUNCHER);
        // Set pending intent
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        notification.setContentIntent(pendingIntent);
        return notification.build();
    }

    /**
     * Updates the content of the current notification.
     *
     * @param content the new content to display in the notification.
     */
    private void updateNotification(String content){
        // Creates new notification
        Notification notification = showNotification(content);
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(NOTIFICATION_ID, notification);
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        // Stop the recognition speech
        speechRecognizer.destroy();
        // Restore system volume
        AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        audioManager.setStreamVolume(AudioManager.STREAM_NOTIFICATION, 6, 0);

        super.onDestroy();
    }
}

/**
 * ### Javadoc Explanation
 *
 * - **Class-level comments** provide an overview of the class's purpose and its static map initialization.
 * - **Method-level comments** explain the purpose, parameters, and return values of each method.
 * - **Parameter tags (`@param`)** describe each method parameter.
 * - **Return tags (`@return`)** describe what the method returns.
 */
