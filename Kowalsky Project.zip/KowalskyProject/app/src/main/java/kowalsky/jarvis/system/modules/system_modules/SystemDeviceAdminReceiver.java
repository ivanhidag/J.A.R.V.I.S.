package kowalsky.jarvis.system.modules.system_modules;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * SystemDeviceAdminReceiver is a broadcast receiver for device admin events.
 */
public class SystemDeviceAdminReceiver extends DeviceAdminReceiver {

    /**
     * Called when the device admin is enabled.
     *
     * @param context The context in which the receiver is running.
     * @param intent  The Intent being received.
     */
    @Override
    public void onEnabled(Context context, Intent intent) {
        super.onEnabled(context, intent);
        // Handle enabling of the device admin
    }

    /**
     * Called when the device admin is disabled.
     *
     * @param context The context in which the receiver is running.
     * @param intent  The Intent being received.
     */
    @Override
    public void onDisabled(Context context, Intent intent) {
        super.onDisabled(context, intent);
        // Handle disabling of the device admin
    }
}
