package kowalsky.jarvis.system.modules.telephony_module;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.provider.ContactsContract;

import java.util.List;

import kowalsky.jarvis.system.bbdd.Database;
import kowalsky.jarvis.system.jarvis.entities.Contact;

/**
 * ContacHelper is a utility class for managing contacts in the device's agenda.
 */
public class ContacHelper {

    /**
     * Retrieves contacts from the device's agenda and saves them in the database.
     *
     * @param context The context to be used for accessing content resolver and database.
     */
    public static void retriveContactAgenda(Context context) {
        // Database
        Database database = new Database(context);
        // Clear table
        database.deleteAllRows("Contactos");
        ContentResolver contentResolver = context.getContentResolver();
        Cursor cursor = contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, null, null, null, null);

        if (cursor != null) {
            while (cursor.moveToNext()) {
                @SuppressLint("Range")
                String name = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME));
                @SuppressLint("Range")
                String phoneNumber = cursor.getString(cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));

                // Save contact
                database.addNewContact(new Contact(name, phoneNumber));
            }
            cursor.close();
        }
    }

    /**
     * Deletes all contacts from the database.
     *
     * @param context The context to be used for accessing the database.
     */
    public static void eliminateAgenda(Context context) {
        Database database = new Database(context);
        database.deleteAllRows("Contactos");
    }

    /**
     * Retrieves all contact names from the database and formats them as a comma-separated string.
     *
     * @param context The context to be used for accessing the database.
     * @return A formatted string containing all contact names, separated by commas.
     */
    public static String getAllContactNamesFormatted(Context context) {
        Database database = new Database(context);
        List<String> contactNames = database.getAllContactNames();

        if (contactNames.isEmpty()) {
            return "No contacts found";
        }

        // Join names with comma and add "lastContact"
        StringBuilder result = new StringBuilder();
        for (int i = 0; i < contactNames.size(); i++) {
            result.append(contactNames.get(i));
            if (i < contactNames.size() - 1) {
                result.append(", ");
            }
        }
        result.append(", lastContact");

        return result.toString();
    }

    /**
     * Retrieves a contact from the database by its name.
     *
     * @param context The context to be used for accessing the database.
     * @param name    The name of the contact to retrieve.
     * @return The contact object if found, or null if not found.
     */
    public static Contact getContact(Context context, String name) {
        Database database = new Database(context);
        if (database.getContact(name) != null) {
            return database.getContact(name);
        }
        return null;
    }
}
