package kowalsky.jarvis.system.jarvis.entities;

/**
 * The Alarma class represents an alarm entity with properties such as title, type, author, hour, and minutes.
 */
public class Alarma {

    private String titulo, tipo, autor;
    private Integer hora, minutos;

    /**
     * Represents the default values code for alarms.
     */
    public static final String DEFAULT_VALUES_CODE = "DVC";

    /**
     * Represents the exact type of alarm.
     */
    public static final String EXACT = "EXACT";

    /**
     * Represents the repeating type of alarm.
     */
    public static final String REPEATING = "REPEATING";

    /**
     * Constructs an Alarma object with the specified properties.
     *
     * @param titulo the title of the alarm.
     * @param tipo the type of the alarm.
     * @param autor the author of the alarm.
     * @param hora the hour of the alarm.
     * @param minutos the minutes of the alarm.
     */
    public Alarma(String titulo, String tipo, String autor, Integer hora, Integer minutos) {
        this.titulo = titulo;
        this.tipo = tipo;
        this.autor = autor;
        this.hora = hora;
        this.minutos = minutos;
    }

    /**
     * Gets the title of the alarm.
     *
     * @return the title of the alarm.
     */
    public String getTitulo() {
        return titulo;
    }

    /**
     * Sets the title of the alarm.
     *
     * @param titulo the title of the alarm.
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /**
     * Gets the type of the alarm.
     *
     * @return the type of the alarm.
     */
    public String getTipo() {
        return tipo;
    }

    /**
     * Sets the type of the alarm.
     *
     * @param tipo the type of the alarm.
     */
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    /**
     * Gets the author of the alarm.
     *
     * @return the author of the alarm.
     */
    public String getAutor() {
        return autor;
    }

    /**
     * Sets the author of the alarm.
     *
     * @param autor the author of the alarm.
     */
    public void setAutor(String autor) {
        this.autor = autor;
    }

    /**
     * Gets the hour of the alarm.
     *
     * @return the hour of the alarm.
     */
    public Integer getHora() {
        return hora;
    }

    /**
     * Sets the hour of the alarm.
     *
     * @param hora the hour of the alarm.
     */
    public void setHora(Integer hora) {
        this.hora = hora;
    }

    /**
     * Gets the minutes of the alarm.
     *
     * @return the minutes of the alarm.
     */
    public Integer getMinutos() {
        return minutos;
    }

    /**
     * Sets the minutes of the alarm.
     *
     * @param minutos the minutes of the alarm.
     */
    public void setMinutos(Integer minutos) {
        this.minutos = minutos;
    }
}
